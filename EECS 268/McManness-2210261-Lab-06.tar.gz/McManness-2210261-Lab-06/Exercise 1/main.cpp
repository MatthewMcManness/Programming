/* -----------------------------------------------------------------------------
 *
 * File Name:  main.cpp
 * Author: Matthew McManness
 * Assignment:   EECS-268 Lab 6 Exercise 1
 * Description:  a program that takes a sequence of parenthesis from the command line. It will indicate whether or not it's a balanced set of parenthesis (matching left and right, not just an equal number).
 * Date: 10-23-2021
 *
 ---------------------------------------------------------------------------- */

#include <iostream>
#include <string>

using namespace std;

void check(string entry, int left, int right, int count);

int main(int argc, char* argv[])
{
	if(argc == 2)
	{	
		int left = 0;
		int right = 0;
		int count = 1;
		check(argv[1], left, right, count);
		return(0);
			
	}
	else
	{
		cout << "Incorrect number of parameters!\n";
		return(0);
	}
	
}

void check(string entry, int left, int right, int count)
{
		if(entry.length() == 0)
		{
			cout << "The sequence " << entry << " is not balanced.\n";
		}
		if((left == 0) && (right == 0))
		{
			if((entry.at(0) == ')')||(entry.length() == count))
			{
				cout << "The sequence " << entry << " is not balanced.\n";
			}
			else
			{
			left++;
			count++;
			check(entry, left, right, count);
			}
		}
		else if(count == entry.length())
		{
			if (entry.at(count-1) == '(')
			{
				left++;
			}
			else
			{
				right++;
			}
			
			if(right != left)
			{
				cout << "The sequence " << entry << " is not balanced.\n";
			}
			else
			{
				cout << "The sequence " << entry << " is balanced.\n";
			}
		}
		else
		{
			if(entry.at(count-1) == '(')
		{
			left++;
			count++;
			check(entry, left, right, count);
		}
		else if(entry.at(count - 1) == ')')
		{
			right++;
			count++;
			check(entry, left, right, count);
		}
		}
}
