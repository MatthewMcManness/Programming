/* -----------------------------------------------------------------------------
 *
 * File Name:  main.cpp
 * Author: Matthew McManness
 * Assignment:   EECS-268 Lab 6 Exercise 3
 * Description: 

 A program that takes an integer and a flag from the user. The flag will indicate one of two options:

  -i
    Short for "ith" where the user wants to know the ith Fibonacci number (note the lowest valid would be zero)
	
  -v
    Short for "verify" where the user wants to know if the number given is in the Fibonacci sequnence

 * Date: 10-25-2021
 *
 ---------------------------------------------------------------------------- */

#include <iostream>
#include <string>

using namespace std;

void populate(int* FibSeq, int size);
void check(int* FibSeq, int choice, int size);

int main(int argc, char* argv[])
{
	if(argc == 3)
	{	
		int* FibSeq = nullptr;
		int size = 47;
		FibSeq = new int[size];
		FibSeq[0] = 0;
		FibSeq[1] = 1;
		int choice = 0;
		string flag = argv[1];
		choice = atoi(argv[2]);
		populate(FibSeq, size);
	
		if(flag == "-i")
		{
			if ((choice < 1) || (choice > 48))
			{
				cout << "Invalid choice (it must be between 1 and " << size << ")\n";
			}
			else
			{	
				cout << "Fibonacci Sequence number at " << choice << ": " << FibSeq[choice - 1] << "\n";
			}
		}
		else if(flag == "-v")
		{
			check(FibSeq, choice, size);
		}
		else
		{
			cout << "please use either \"-i\" or \"-v\" for your flag\n";
		}		
		return(0);
	}
	else
	{
		cout << "Incorrect number of parameters!\n";
		return(0);
	}

}

void populate(int* FibSeq, int size)
{
	if(size == 2)
	{
		FibSeq[size] = FibSeq[size-1] + FibSeq[size - 2];
	}
	else
	{
		populate(FibSeq, (size-1));
		FibSeq[size] = FibSeq[size-1] + FibSeq[size - 2];
	}
}

void check(int* FibSeq, int choice, int size)
{
	if(size == 0)
	{
		if(choice == FibSeq[size])
		{
			cout << choice << " is in the sequence.\n";
		}
		else
		{
			cout << choice << " is not in the sequence.\n";
		}
	}
	else
	{
		if(choice == FibSeq[size])
		{
			cout << choice << " is in the sequence.\n";
		}
		else
		{
			check(FibSeq, choice, (size-1));
		}
	}
	
}