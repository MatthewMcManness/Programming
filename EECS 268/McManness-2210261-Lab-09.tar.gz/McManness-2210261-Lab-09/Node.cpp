/** -----------------------------------------------------------------------------
 *
 * @file  Node.cpp
 * @author Matthew McManness 
 * Assignment:   EECS-268 Lab 9
 * @brief This is the cpp file that defines the methods of the Node class.
 * @date 11/30/21
 *
 ---------------------------------------------------------------------------- **/
 using namespace std;
 #include <stdexcept>
template <typename T>
Node<T>::Node(T entry)
{
	m_entry = entry;
	m_left = nullptr;
	m_right = nullptr;
}

template <typename T>
T Node<T>::getEntry() const
{
	return(m_entry);
}

template <typename T>
void Node<T>::setEntry(T entry)
{
	m_entry = entry;
}

template <typename T>
Node<T>* Node<T>::getLeft()
{
		return(m_left);
}

template <typename T>
Node<T>* Node<T>::getRight()
{
		return(m_right);
}

template <typename T>
void Node<T>::setLeft(Node<T>* left)
{
	m_left = left;
}

template <typename T>
void Node<T>::setRight(Node<T>* right)
{
	m_right = right;
}