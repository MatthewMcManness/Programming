/** -----------------------------------------------------------------------------
 *
 * @file  pokemon.h
 * @author Matthew McManness 
 * Assignment:   EECS-268 Lab 9
 * @brief This is the header file that describes what the pokemon class can do.
 * @date 11/30/21
 *
 ---------------------------------------------------------------------------- **/
 
#ifndef POKEMON_H
#define POKEMON_H

#include <string>
using namespace std;
class pokemon
{
	private:
	int m_num = 0;
	string m_america = "";
	string m_japan = "";
	public:
	pokemon() {}
	pokemon(int num, string america, string japan);
	~pokemon() {}
	void setNum(int num);
	void setAmerica(string america);
	void setJapan(string japan);
	int getNum() const ;
	string getAmerica() const ;
	string getJapan() const ;
	bool operator>(const pokemon& rhs) const;
	bool operator<(const pokemon& rhs) const;
	bool operator==(const pokemon& rhs) const;
	bool operator>(const int rhs) const;
	bool operator<(const int rhs) const;
	bool operator==(const int rhs) const;
};
#endif