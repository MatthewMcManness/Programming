/** -----------------------------------------------------------------------------
 *
 * @file  pokemon.cpp
 * @author Matthew McManness 
 * Assignment:   EECS-268 Lab 9
 * @brief This is the header file that defines what the pokemon class can do.
 * @date 11/30/21
 *
 ---------------------------------------------------------------------------- **/
 
 #include <string>
 #include "pokemon.h"
 #include <stdexcept>
 #include <iostream>
 using namespace std;
 pokemon::pokemon(int num, string america, string japan)
 {
	 try
	 {
		setNum(num);
	 }
	 catch(runtime_error& rte)
	 {
		 cout << "Something went wrong!\n" << rte.what() << '\n';
	 }
	setAmerica(america);
	setJapan(japan);
 }
 
 void pokemon::setNum(int num)
 {
	 if(num > 0)
	 {
		m_num = num;
	 }
	 else
	 {
		 throw(runtime_error("Number smaller than 1"));
	 }
	 
 }
 
 void pokemon::setAmerica(string america)
 {
	 m_america = america;
 }
 
 void pokemon::setJapan(string japan)
 {
	 m_japan = japan;
 }
 
int pokemon::getNum()  const 
 {
	 return(m_num);
 }

string pokemon::getAmerica() const 
{
	return(m_america);
}

string pokemon::getJapan() const
{
	return(m_japan);
}

bool pokemon::operator>(const pokemon& rhs) const
{
	return(getNum() > rhs.getNum());
}

bool pokemon::operator<(const pokemon& rhs) const
{
	return(!(getNum() > rhs.getNum()));
}

bool pokemon::operator==(const pokemon& rhs) const
{
	return(getNum() == rhs.getNum());
}

bool pokemon::operator>(const int rhs) const
{
	return(getNum() > rhs);
}

bool pokemon::operator<(const int rhs) const
{
	return(!(getNum() > rhs));
}

bool pokemon::operator==(const int rhs) const
{
	return(getNum() == rhs);
}