/** -----------------------------------------------------------------------------
 *
 * @file  Node.h
 * @author Matthew McManness 
 * Assignment:   EECS-268 Lab 9
 * @brief This is the header file that describes what the Node class can do.
 * @date 11/30/21
 *
 ---------------------------------------------------------------------------- **/
 
#ifndef NODE_H
#define NODE_H


template <typename T>
class Node 
{
	private:
	T m_entry;
	Node<T>* m_left;
	Node<T>* m_right;
	
	public:
	
	/*
       * @pre None
       * @post creates a new Node with an type (entry)
       * @param entry, the element to be contained inside the Node
       * @throw None
    */
	Node(T entry);
	
	/*
       * @pre None
       * @post returns the entry inside of the node.
       * @param None
       * @throw None
    */
	T getEntry() const;
	
	/*
       * @pre None
       * @post changes the entry contained within the node.
       * @param entry, the element to be contained inside the Node
       * @throw None
    */
	void setEntry(T entry);
	
	/*
       * @pre None
       * @post returns the left Node* (pointer to the left node)
       * @param None
       * @throw None
    */
	Node<T>* getLeft();
	
	/*
      * @pre None
      * @post returns the right Node* (pointer to the right node)
      * @param None
      * @throw None
    */
	Node<T>* getRight();
	
	/*
       * @pre None
       * @post sets the Node to point at a different left node (left is the pointer)
       * @param left, the pointer to the different node.
       * @throw None
    */
	void setLeft(Node<T>* left);
	
	/*
      * @pre None
      * @post sets the Node to point at a different right node (right is the pointer)
      * @param right, the pointer to the different node.
      * @throw None
    */
	void setRight(Node<T>* right);
};

#include "Node.cpp"
#endif
