/** -----------------------------------------------------------------------------
 *
 * @file  executive.cpp
 * @author Matthew McManness 
 * Assignment:   EECS-268 Lab 9
 * @brief The class file for executive defines how the pokedex will work.
 * @date 12/1/21
 *
 ---------------------------------------------------------------------------- **/

#include <string>
#include <iostream>
#include <fstream>
#include <stdexcept>
#include "pokemon.h"
#include "BST.h"
#include "Node.h"
#include "BSTInterface.h"
#include "executive.h"

using namespace std;

executive::executive(string fileName)
{
	m_fileName = fileName;
}

void executive::openfile()
{
	m_inputFile.open(m_fileName);
}

void executive::run()
{

	openfile();

	if(m_inputFile.is_open())
	{
		m_inputFile >> m_USTemp >> m_IDTemp >> m_JPTemp;
		pokemon temp1(m_IDTemp, m_USTemp, m_JPTemp);
		BinarySearchTree<pokemon, int> pokedex(temp1);
		while(m_inputFile >> m_USTemp >> m_IDTemp >> m_JPTemp)
		{
			pokemon temp(m_IDTemp, m_USTemp, m_JPTemp);
			
			pokedex.add(temp);
		}
		while(true)
		{
			cout << "\nWhat would you like to do?: \n1. Search\n2. Add\n3. Print\n4. Quit\nSelection: ";
			cin >> m_command;
		
			if(m_command == 1)
			{
				cout << "What Pokedex ID would you like to search for?: ";
				cin >> m_key;
				try{
				temp1 = pokedex.search(m_key);
				visit(temp1);
				}
				catch(runtime_error rte)
				{
					cout << "\nPokemon " << rte.what() << '\n';
				}
				
			}
			else if(m_command == 2)
			{
				cout << "What is the new Pokemon's ID number?: ";
				cin >> m_IDTemp;
				
				cout << "What is the new Pokemon's American name?: ";
				cin >> m_USTemp;
				
				cout << "What is the new Pokemon's Japanese name?: ";
				cin >> m_JPTemp;
				
				pokemon temp(m_IDTemp, m_USTemp, m_JPTemp);
				
				try
				{
				pokedex.add(temp);
				cout << "\nYour Pokemon was added!\n";
				}
				catch(runtime_error& rte)
				{
					cout << "This Pokemon " << rte.what() << '\n';
				}
			}
			else if(m_command == 3)
			{
				while(true)
				{
					cout << "\nWhat order would you like?: \n1. Pre\n2. In\n3. Post\n";
					cin >> m_order;
				
					if(m_order == 1)
					{
						pokedex.visitPreOrder(visit);
						break;
					}
					else if(m_order == 2)
					{
						pokedex.visitInOrder(visit);
						break;
						
					}
					else if(m_order == 3)
					{
						pokedex.visitPostOrder(visit);
						break;
					}
					else
					{
						cout << "Please enter a number between 1 and 3\n";
					}
				}
				
			}
			else if(m_command == 4)
			{
				cout << '\n';
				exit(0);
			}
			else
			{
				cout << "Please enter a number between 1 and 4\n";
			}
				
		}
		
	}
	else
	{
		cout << "\nThe file " << m_fileName << " could not be opened.\n\n";
	}	
}

void executive::visit(pokemon poke)
{
	cout << "-------------------\n\nPokedex ID: " << poke.getNum() << "\nAmerican Name: " << poke.getAmerica() << "\nJapanese Name: " << poke.getJapan() << "\n\n--------------------\n";
}




