/** -----------------------------------------------------------------------------
 *
 * @file  BST.cpp
 * @author Matthew McManness 
 * Assignment:   EECS-268 Lab 9
 * @brief This is the cpp file that defines the methods of the BinarySearchTree class.
 * @date 12/1/21
 *
 ---------------------------------------------------------------------------- **/
 using namespace std;
 #include <stdexcept>
 #include <iostream>
 #include "Node.h"
 #include "executive.h"
 
 
 template <typename ItemType, typename KeyType>
 BinarySearchTree<ItemType, KeyType>::BinarySearchTree(ItemType first)
 {
	 m_start = new Node<ItemType>(first);
 }
 
 template <typename ItemType, typename KeyType>
 void BinarySearchTree<ItemType, KeyType>::add(ItemType entry)
 {
	 m_temp = m_start;
	
	 while(true)
	 {
		 
		if(m_temp == nullptr)
		{
			break;
		}
		 m_entry = m_temp->getEntry();
		if(m_entry == entry)
		{
			throw(runtime_error("already exists!"));
		}
		else
		{
			if(m_entry > entry)
			{
				m_temp = m_temp->getLeft();
			}
			else
			{
				m_temp = m_temp->getRight();
			}
		}
	 }
		
	 m_temp = m_start;
	 m_new = new Node<ItemType>(entry);
	 while(true)
	 {
		 m_entry = m_temp->getEntry();
		if(m_entry > entry)
		{
			if(m_temp->getLeft() == nullptr)
			{
				m_temp->setLeft(m_new);
				break;
			}
			else
			{
				m_temp = m_temp->getLeft();
			}
		 }
		 else if (m_entry < entry)
		 {
			 if(m_temp->getRight() == nullptr)
			 {
				 m_temp->setRight(m_new);
				 break;
			 }
			 else
			 {
				 m_temp = m_temp->getRight();
			 }
		 }
	 }
 }

template <typename ItemType, typename KeyType>
ItemType BinarySearchTree<ItemType, KeyType>::search(KeyType key)
 {
	 m_temp = m_start;
	
	 while(true)
	 {
		 
		if(m_temp == nullptr)
		{
			throw(runtime_error("does not exist"));
		}
		 m_entry = m_temp->getEntry();
		if(m_entry == key)
		{
			return(m_entry);
		}
		else
		{
			if(m_entry > key)
			{
				m_temp = m_temp->getLeft();
			}
			else
			{
				m_temp = m_temp->getRight();
			}
		}
	 }
		
 }

template <typename ItemType, typename KeyType>
void BinarySearchTree<ItemType, KeyType>::clear()
{
	m_start = nullptr;
}
 
/*
template <typename ItemType, typename KeyType>
void BinarySearchTree<ItemType, KeyType>::remove(KeyType key)
 {
	 m_temp = m_start;
	
	 while(true)
	 {
		 m_left = m_temp->getLeft();
		 m_right = m_temp->getRight();
		if(m_temp == nullptr)
		{
			throw(runtime_error("does not exist"));
		}
		 m_entry = m_temp->getEntry();
		 m_entry_left = m_left->getEntry();
		 m_entry_right = m_right->getEntry();
		 if(m_entry_left == key)
		 {
			 m_entry->setLeft(nullptr)
		 }
		 else if(m_entry_right == key);
		 {
			 m_entry->setRight(nullptr);
		 }
		else
		{
			if(m_entry > key)
			{
				m_temp = m_temp->getLeft();
			}
			else
			{
				m_temp = m_temp->getRight();
			}
		}
	 }
		
 }
 */
 

    //For the following methods, each method will take a function as a parameter
    //These function then call the provided function on every entry in the tree in the appropriate order (i.e. pre, in, post)
    //The function you pass in will need to a static method
template <typename ItemType, typename KeyType>
void BinarySearchTree<ItemType, KeyType>::visitPreOrder(void visit(ItemType)) const
{
	visitPreOrderTool(visit, m_start);
	
}

template <typename ItemType, typename KeyType>
void BinarySearchTree<ItemType, KeyType>::visitPreOrderTool(void visit(ItemType), Node<ItemType>* root) const
{
	if(root == nullptr)
	{
		return;
	}
	visit(root->getEntry());
	visitPreOrderTool(visit, root->getLeft());
	visitPreOrderTool(visit, root->getRight());
	
}


template <typename ItemType, typename KeyType>
void BinarySearchTree<ItemType, KeyType>::visitInOrder(void visit(ItemType)) const
{
	visitInOrderTool(visit, m_start);
	
}

template <typename ItemType, typename KeyType>
void BinarySearchTree<ItemType, KeyType>::visitInOrderTool(void visit(ItemType), Node<ItemType>* root) const
{
	if(root == nullptr)
	{
		return;
	}
	visitInOrderTool(visit, root->getLeft());
	visit(root->getEntry());
	visitInOrderTool(visit, root->getRight());
	
}

template <typename ItemType, typename KeyType>
void BinarySearchTree<ItemType, KeyType>::visitPostOrder(void visit(ItemType)) const
{
	visitPostOrderTool(visit, m_start);
	
}

template <typename ItemType, typename KeyType>
void BinarySearchTree<ItemType, KeyType>::visitPostOrderTool(void visit(ItemType), Node<ItemType>* root) const
{
	if(root == nullptr)
	{
		return;
	}
	visitPostOrderTool(visit, root->getLeft());
	visitPostOrderTool(visit, root->getRight());
	visit(root->getEntry());
	
}