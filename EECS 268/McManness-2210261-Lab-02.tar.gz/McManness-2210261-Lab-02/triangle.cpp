/** -----------------------------------------------------------------------------
 *
 * @file  triangle.cpp
 * @author Matthew McManness 
 * Assignment:   EECS-268 Lab 2
 * @brief The file that defines what triangles can do.
 * @date 9/20/21
 *
 ---------------------------------------------------------------------------- **/
#include "triangle.h"
#include <string>

using namespace std;

Triangle::Triangle(double base, double height)
{
	setBase(base);
	setHeight(height);
}

double Triangle::area() const
{
	
	return(0.5*m_base*m_height);
}

string Triangle::shapeName() const
{
	return(m_shapeName);
}

void Triangle::setBase(double base)
{
	if(base > 0)
	{
		m_base = base;
	}
}

void Triangle::setHeight(double height)
{
	if(height > 0)
	{
		m_height = height;
	}
}

Triangle::~Triangle()
{
}
