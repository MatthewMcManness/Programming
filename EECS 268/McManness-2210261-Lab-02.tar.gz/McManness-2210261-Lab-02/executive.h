/** -----------------------------------------------------------------------------
 *
 * @file  executive.h
 * @author Matthew McManness 
 * Assignment:   EECS-268 Lab 2
 * @brief The header file for the executive class.
 * @date 9/20/21
 *
 ---------------------------------------------------------------------------- **/
#include <string>
#include <iostream>
#include <fstream>
#include "shapecontainer.h"
#include "shape.h"

using namespace std;

#ifndef EXECUTIVE_H
#define EXECUTIVE_H

class executive
{
	private:
	string m_fileName;
	ifstream m_inputFile;
	int m_size;
	string m_command;
	string m_shape;
	int m_index;
	double m_value1;
	double m_value2;
	Shape* m_temporaryShape;
	
	public:
	executive(string fileName);

	void run(); // interactes with the file 
	void openfile(); // opens the file
	void add(ShapeContainer& shapeArray); // adds new entries to the array
	void remove(ShapeContainer& shapeArray); // deletes an entry
	void print(ShapeContainer& shapeArray); // prints the entry in the correct format




};

#endif

