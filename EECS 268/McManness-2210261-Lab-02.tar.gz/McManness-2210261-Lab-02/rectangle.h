/** -----------------------------------------------------------------------------
 *
 * @file  rectangle.h
 * @author Matthew McManness 
 * Assignment:   EECS-268 Lab 2
 * @brief The header file for rectangles.
 * @date 9/20/21
 *
 ---------------------------------------------------------------------------- **/
#include <string>

using namespace std;

#ifndef RECTANGLE_H
#define RECTANGLE_H

#include "shape.h"

class Rectangle : public Shape
{
	private:
	double m_length;
	double m_width;
	string m_shapeName = "Rectangle";
	
	public:
	Rectangle(double length, double width); //creates a rectangle with a name, length and width
	
	double area() const; //returns m_lenght * m_width
	string shapeName() const; //returns the shapes name
	void setLength(double length); //sets m_length
	void setWidth(double width); // sets m_width
	
	~Rectangle();
};
#endif