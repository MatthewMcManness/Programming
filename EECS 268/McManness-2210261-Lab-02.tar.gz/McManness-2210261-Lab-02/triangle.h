/** -----------------------------------------------------------------------------
 *
 * @file  triangle.h
 * @author Matthew McManness 
 * Assignment:   EECS-268 Lab 2
 * @brief The header file for triangles.
 * @date 9/20/21
 *
 ---------------------------------------------------------------------------- **/


#include <string>

using namespace std;

#ifndef TRIANGLE_H
#define TRIANGLE_H

#include "shape.h"

class Triangle : public Shape
{
	private:
	double m_base;
	double m_height;
	string m_shapeName = "Triangle";
	
	public:
	Triangle(double base, double height); // initiallizes a Triangle with a set base and height
	
	double area() const; // returns the area
	string shapeName() const; // returns the shape name
	void setBase(double base); // sets the base as long as it is a positive number
	void setHeight(double height);// sets the height as long as it is a positive number
	~Triangle();
};
#endif