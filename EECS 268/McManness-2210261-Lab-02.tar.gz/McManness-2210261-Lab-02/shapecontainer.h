/** -----------------------------------------------------------------------------
 *
 * @file  shapecontainer.h
 * @author Matthew McManness 
 * Assignment:   EECS-268 Lab 2
 * @brief The header file for shapecontainer (an array of shape pointers).
 * @date 9/20/21
 *
 ---------------------------------------------------------------------------- **/

#include <string>
#include "shape.h"
#include <stdexcept>

using namespace std;

#ifndef SHAPE_CONTAINER_H
#define SHAPE_CONTAINER_H
 
class ShapeContainer
{
	private:
	Shape** m_arrayOfShapes;
	int m_size;
	Shape* temporary = nullptr;
	
	public:
	ShapeContainer(int size);//initialize pointers in m_arrayOfShapes to nullptr
	~ShapeContainer();
	double area(int index) const; //throws a std::runtime_error if index is invalid, meaning out of range OR index has nullptr 
	string shapeName(int index) const; //throws a std::runtime_error if index is invalid, meaning out of range OR index has nullptr
	void add(Shape* shapePtr, int index); //throws a std::runtime_error if index is invalid OR if shapePtr is nullptr
	void remove(int index); //throws a std::runtime_error if the index is invalid OR there is no object to delete
};
#endif

#include <stdexcept>
