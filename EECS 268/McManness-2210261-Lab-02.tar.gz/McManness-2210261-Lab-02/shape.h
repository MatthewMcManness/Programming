/** -----------------------------------------------------------------------------
 *
 * @file  shape.h
 * @author Matthew McManness 
 * Assignment:   EECS-268 Lab 2
 * @brief The header file for shapes.
 * @date 9/20/21
 *
 ---------------------------------------------------------------------------- **/

#include <string>

using namespace std;

#ifndef SHAPE_H
#define SHAPE_H

class Shape
{
	public:
	virtual double area() const = 0;
	virtual std::string shapeName() const = 0;
	virtual ~Shape() {}
};
#endif
