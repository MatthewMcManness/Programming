/** -----------------------------------------------------------------------------
 *
 * @file  main.cpp
 * @author Matthew McManness 
 * Assignment:   EECS-268 Lab 2
 * @brief The file that checks to see if the command line is correct and then runs through "executive.cpp". The program as a whole reads instructions about shapes in from a file and the follows those instructions (creates, destroys, and prints shapes and their areas).
 * @date 9/20/21
 *
 ---------------------------------------------------------------------------- **/
#include <iostream>
#include <fstream>
#include <string>
#include "executive.h"

using namespace std;



int main(int argc, char* argv[])
{

	if(argc == 2)
	{		

			executive exec(argv[1]);

			exec.run();

			return(0);
			
	}
	else
	{
		cout << "Incorrect number of parameters!";
		return(0);
	}
	
}
