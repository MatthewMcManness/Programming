/** -----------------------------------------------------------------------------
 *
 * @file  circle.h
 * @author Matthew McManness 
 * Assignment:   EECS-268 Lab 2
 * @brief The header file for Circles.
 * @date 9/20/21
 *
 ---------------------------------------------------------------------------- **/
#include <string>

using namespace std;

#ifndef CIRCLE_H
#define CIRCLE_H

#include "shape.h"
 
class Circle : public Shape
{
	private:
	double m_radius; 
	string m_shapeName = "Circle";
	
	public:
	Circle(double radius); // initializes a circle with a set radius
	
	double area() const; // returns the area
	string shapeName() const; //  returns the shape name
	void setRadius(double radius); // sets a new radius as long as it is a positive number
	~Circle();
};
#endif