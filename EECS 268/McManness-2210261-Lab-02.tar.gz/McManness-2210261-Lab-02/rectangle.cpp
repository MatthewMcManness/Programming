/** -----------------------------------------------------------------------------
 *
 * @file  rectangle.cpp
 * @author Matthew McManness 
 * Assignment:   EECS-268 Lab 2
 * @brief The file that defines what rectangles can do.
 * @date 9/20/21
 *
 ---------------------------------------------------------------------------- **/
#include "rectangle.h"
#include <string>

using namespace std;

Rectangle::Rectangle(double length, double width)
{
	setLength(length);
	setWidth(width);
}

double Rectangle::area() const
{
	return(m_length*m_width);
}

string Rectangle::shapeName() const
{
	return(m_shapeName);
}

void Rectangle::setLength(double length)
{
	if(length > 0)
	{
		m_length = length;
	}
}

void Rectangle::setWidth(double width)
{
	if(width > 0)
	{
		m_width = width;
	}
}

Rectangle::~Rectangle()
{
}