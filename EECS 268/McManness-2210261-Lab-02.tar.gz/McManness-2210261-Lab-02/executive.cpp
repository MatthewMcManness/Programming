/** -----------------------------------------------------------------------------
 *
 * @file  executive.cpp
 * @author Matthew McManness 
 * Assignment:   EECS-268 Lab 2
 * @brief The class file for executive (does the bulk of the work in terms of interactions with other classes and the main file).
 * @date 9/20/21
 *
 ---------------------------------------------------------------------------- **/

#include <string>
#include <iostream>
#include <fstream>
#include "executive.h"
#include "shapecontainer.h"
#include "shape.h"
#include "circle.h"
#include "triangle.h"
#include "rectangle.h"

using namespace std;

executive::executive(string fileName)
{
	m_fileName = fileName;
}

void executive::openfile()
{
	m_inputFile.open(m_fileName);
}

void executive::add(ShapeContainer& shapeArray)
{
	m_inputFile >> m_index >> m_shape;
	if(m_shape == "CIR")
	{
		m_inputFile >> m_value1;
		m_temporaryShape = new Circle(m_value1);
		try
		{
			shapeArray.add(m_temporaryShape, m_index);
		
		}
		catch(runtime_error& rte)
		{
			cout << "Something went wrong!\n" << rte.what() << "\n\n";
		}
	}
	else if(m_shape == "TRI")
	{
		m_inputFile >> m_value1 >> m_value2;
		m_temporaryShape = new Triangle(m_value1, m_value2);
		try
		{
			shapeArray.add(m_temporaryShape, m_index);
		}
		catch(runtime_error& rte)
		{
			cout << "Something went wrong!\n" << rte.what() << "\n\n";
		}

	}
	else if(m_shape == "REC")
	{
		m_inputFile >> m_value1 >> m_value2;
		m_temporaryShape = new Rectangle(m_value1, m_value2);
		try
		{
			shapeArray.add(m_temporaryShape, m_index);
		}
		catch(runtime_error& rte)
		{
			cout << "Something went wrong!\n" << rte.what() << "\n\n";
		}
	}
}


void executive::remove(ShapeContainer& shapeArray)
{
	m_inputFile >> m_index;
	shapeArray.remove(m_index);
}

void executive::print(ShapeContainer& shapeArray)
{

	m_inputFile >> m_index;
	cout << "Shape at index " << m_index << ": ";
	try
	{

		cout << shapeArray.shapeName(m_index) << " area = " << shapeArray.area(m_index) << '\n';
	}
	catch(runtime_error& rte)
	{
		cout << "Shape does not exist\n";
	}
}

void executive::run()
{

	openfile();

	if(m_inputFile.is_open())
	{

		m_inputFile >> m_size;

		ShapeContainer shapeArray(m_size);
		while(m_command != "EXIT")
		{

			m_inputFile >> m_command;
		
			if(m_command == "ADD")
			{
				add(shapeArray);
			}
			else if(m_command == "DELETE")
			{
				remove(shapeArray);
			}
			else if(m_command == "PRINT")
			{
				print(shapeArray);
			}
			else if(m_command == "EXIT")
			{
				break;
			}
		}
	}
	else
	{
		cout << "\nThe file " << m_fileName << " could not be opened.\n\n";
	}	
}



