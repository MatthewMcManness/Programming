#include <string>
#include <stdexcept>
#include <iostream>
/** -----------------------------------------------------------------------------
 *
 * @file  shapecontainer.cpp
 * @author Matthew McManness 
 * Assignment:   EECS-268 Lab 2
 * @brief The file that defines what shapecontainers can do.
 * @date 9/20/21
 *
 ---------------------------------------------------------------------------- **/
#include "shapecontainer.h"
#include "shape.h"

using namespace std;

ShapeContainer::ShapeContainer(int size)
{
	m_size = size;
	m_arrayOfShapes = new Shape*[m_size];
	for(int i = 0; i< m_size; i++)
	{
		m_arrayOfShapes[i] = temporary;
	}			
	delete[] temporary;
}

double ShapeContainer::area(int index) const
{
	if((index >= 0) && (index < m_size) && (m_arrayOfShapes[index] != nullptr))
	{
	return(m_arrayOfShapes[index]->area());
	}
	else
	{
		throw(runtime_error("Shape does not exist"));
	}
}

string ShapeContainer::shapeName(int index) const
{
	if((index < 0) || (index >= m_size) || (m_arrayOfShapes[index] == nullptr))
	{
		throw(runtime_error("Shape does not exist"));
	}
	else
	{
		if(m_arrayOfShapes[index] == nullptr)
		{
			return("Shape does not exist");
		}
		return(m_arrayOfShapes[index]->shapeName());
	}
}


void ShapeContainer::add(Shape* shapePtr, int index) 
{
	if((index < 0) && (index >= m_size))
	{
		throw(runtime_error("Shape does not exist"));
	}
	else if(shapePtr == nullptr)
	{
		throw(runtime_error("Shape does not exist"));
	}
	else
	{
		m_arrayOfShapes[index] = shapePtr;
	}
}

void ShapeContainer::remove(int index) 
{
	if((index >= 0) && (index < m_size))
	{
		m_arrayOfShapes[index] = nullptr;
	}
	else
	{
		throw(runtime_error("Shape does not exist"));
	}
}

ShapeContainer::~ShapeContainer()
{
	for(int i = 0; i < m_size; i++)
	{
		delete m_arrayOfShapes[i];
	}
	delete[] m_arrayOfShapes;
}
