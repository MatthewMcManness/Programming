/** -----------------------------------------------------------------------------
 *
 * @file  circle.cpp
 * @author Matthew McManness 
 * Assignment:   EECS-268 Lab 2
 * @brief The file that defines what circles can do.
 * @date 9/20/21
 *
 ---------------------------------------------------------------------------- **/
#include "circle.h"
#include <string>

using namespace std;

Circle::Circle(double radius)
{
	setRadius(radius);
}

double Circle::area() const
{
	return((22/7)*m_radius*m_radius);
}

string Circle::shapeName() const
{
	return(m_shapeName);
}

void Circle::setRadius(double radius)
{
	if(radius > 0)
	{
		m_radius = radius;
	}
}

Circle::~Circle()
{
}

