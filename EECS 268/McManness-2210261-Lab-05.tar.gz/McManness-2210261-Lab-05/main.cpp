/** -----------------------------------------------------------------------------
 *
 * @file  main.cpp
 * @author Matthew McManness 
 * Assignment:   EECS-268 Lab 5
 * @brief The file that checks to see if the command line is correct and then sends the filename to the exucutive class.
 * @date 10/18/21
 *
 ---------------------------------------------------------------------------- **/
#include <string>
#include "executive.h"
#include <iostream>

using namespace std;



int main(int argc, char* argv[])
{

	if(argc == 2)
	{		

			executive exec(argv[1]);

			exec.run();

			return(0);
			
	}
	else
	{
		cout << "Incorrect number of parameters!\n";
		return(0);
	}
	
}