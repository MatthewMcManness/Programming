/** -----------------------------------------------------------------------------
 *
 * @file  BrowserHistory.cpp
 * @author Matthew McManness 
 * Assignment:   EECS-268 Lab 5
 * @brief This file defines what this Browser History will be able to do and how to do it.
 * @date 10/18/21
 *
 ---------------------------------------------------------------------------- **/
 
 #include "BrowserHistory.h"
 #include "BrowserHistoryInterface.h"
 #include "ListInterface.h"
 #include "LinkedList.h"
 #include "Node.h"
 #include <string>

 
 using namespace std;
 
 BrowserHistory::BrowserHistory()
 {
	 m_history = new LinkedList<string>();
 }
 
 void BrowserHistory::navigateTo(string url)
 {
	 m_history->insert(1, url);
	 m_currentIndex = 1;
 }
 
 void BrowserHistory::forward()
 {
	 if(m_currentIndex > 1)
	 {
		m_currentIndex--;
	 }
 }
 
 void BrowserHistory::back()
 {
	 if(m_currentIndex < m_history->length())
	 {	 
		m_currentIndex++;
	 }
 }
 
 string BrowserHistory::current()const
 {
	 if(m_currentIndex > 0)
	 {
	 return(m_history->getEntry(m_currentIndex));
	 }
	 return("");
 }
 
 void BrowserHistory::copyCurrentHistory(ListInterface<string>& destination)
 {
	 destination.insert(1, m_history->getEntry(1));
	 for(int i = 1; i <= m_history->length(); i++)
	 {
	 destination.insert(i,m_history->getEntry(i));
	 }

 }