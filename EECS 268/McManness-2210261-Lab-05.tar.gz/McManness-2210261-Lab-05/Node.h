/** -----------------------------------------------------------------------------
 *
 * @file  Node.h
 * @author Matthew McManness 
 * Assignment:   EECS-268 Lab 5
 * @brief This is the header file that describes what the Node class can do.
 * @date 10/18/21
 *
 ---------------------------------------------------------------------------- **/
 
#ifndef NODE_H
#define NODE_H


template <typename T>
class Node 
{
	private:
	T m_entry;
	Node<T>* m_next;
	
	public:
	
	/*
       * @pre None
       * @post creates a new Node with an type (entry)
       * @param entry, the element to be contained inside the Node
       * @throw None
    */
	Node(T entry);
	
	/*
       * @pre None
       * @post returns the entry inside of the node.
       * @param None
       * @throw None
    */
	T getEntry() const;
	
	/*
       * @pre None
       * @post changes the entry contained within the node.
       * @param entry, the element to be contained inside the Node
       * @throw None
    */
	void setEntry(T entry);
	
	/*
       * @pre None
       * @post returns the Node* (pointer to the next node)
       * @param None
       * @throw None
    */
	Node<T>* getNext();
	
	/*
       * @pre None
       * @post sets the Node to point at a different node (next is the pointer)
       * @param next, the pointer to the different node.
       * @throw None
    */
	void setNext(Node<T>* next);
};

#include "Node.cpp"
#endif
