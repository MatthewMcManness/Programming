/** -----------------------------------------------------------------------------
 *
 * @file  BrowserHistory.h
 * @author Matthew McManness 
 * Assignment:   EECS-268 Lab 5
 * @brief This file outlines what this Browser History will be able to do.
 * @date 10/18/21
 *
 ---------------------------------------------------------------------------- **/
 
 #ifndef BROWSERHISTORY_H
 #define BROWSERHISTORY_H
 
 #include "BrowserHistoryInterface.h"
 #include "ListInterface.h"
 #include "LinkedList.h"
 #include "Node.h"
 #include <string>
 
 using namespace std;
 
 class BrowserHistory : public BrowserHistoryInterface
 {

	private:
	
	ListInterface<string>* m_history = nullptr;
	int m_currentIndex = 0;
	
	public:
  
	BrowserHistory();
  
  /**
  * @post All memory allocated by the implementing class should be freed. 
  *       This, as with all virtual destrucors, is an empty definition since we
  *       have no knowledge of specific implementation details.
  */
	virtual ~BrowserHistory(){} 

  /**
  * @pre none
  * @post the browser navigate to the given url
  * @param url, a string representing a URL
  */
	virtual void navigateTo(string url);

  /**
  * @pre none
  * @post if possible, the browser navigates forward in the history otherwise it keeps focus
  *         on the current URL
  */
	virtual void forward();

  /**
  * @pre none
  * @post if possible, the browser navigates backwards in the history otherwise it keeps focus
  *         on the current URL 
  */
	virtual void back();

  /**
  * @return the current URL 
  */
	virtual string current() const;

  /**
  * @pre The list being passed in is empty
  * @post The current browser history is copied into the given list  
  * @param destination, an empty list of strings
  */
	virtual void copyCurrentHistory(ListInterface<string>& destination);
	
};
 
 #endif