/** -----------------------------------------------------------------------------
 *
 * @file  Node.cpp
 * @author Matthew McManness 
 * Assignment:   EECS-268 Lab 5
 * @brief This is the cpp file that defines the methods of the Node class.
 * @date 10/18/21
 *
 ---------------------------------------------------------------------------- **/
 using namespace std;
 #include <stdexcept>
template <typename T>
Node<T>::Node(T entry)
{
	m_entry = entry;
	m_next = nullptr;
}

template <typename T>
T Node<T>::getEntry() const
{
	return(m_entry);
}

template <typename T>
void Node<T>::setEntry(T entry)
{
	m_entry = entry;
}

template <typename T>
Node<T>* Node<T>::getNext()
{
		return(m_next);
}

template <typename T>
void Node<T>::setNext(Node<T>* next)
{
	m_next = next;
}