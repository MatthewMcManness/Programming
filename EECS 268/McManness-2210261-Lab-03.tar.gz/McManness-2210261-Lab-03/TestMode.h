/** -----------------------------------------------------------------------------
 *
 * @file  TestMode.h
 * @author Matthew McManness 
 * Assignment:   EECS-268 Lab 3
 * @brief This header file defines what "Test Mode" can do.
 * @date 9/27/21
 *
 ---------------------------------------------------------------------------- **/
 #ifndef TEST_MODE_H
#define TEST_MODE_H

#include <stdexcept>
#include <iostream>
 class TestMode
{   
    public: 

    TestMode();

	/*
       * @pre None
       * @post This will call all your test methods
       * @param None
       * @throw None
    */
    void runTests();
     
    private:
	
	bool m_run;
	
	/*
       * @pre None
       * @post Creates an empty stack and verifies isEmpty() returns true
       * @param None
       * @throw None
    */
    void test01();

	/*
       * @pre None
       * @post Creates an empty stack pushes 1 value, verifies isEmpty() returns false
       * @param None
       * @throw None
    */
    void test02();


	/*
       * @pre None
       * @post Creates an empty stack, then pushes once, pops once, and verifies isEmpty returns true
       * @param None
       * @throw None
    */
    void test03();

    /*
       * @pre None
       * @post Creates an empty stack, then pushes three times, Creates a new stack using the copy constructor and verifies that the elements are in the correct order using the = operator.
       * @param None
       * @throw None
    */
	void test04();
};
 #endif