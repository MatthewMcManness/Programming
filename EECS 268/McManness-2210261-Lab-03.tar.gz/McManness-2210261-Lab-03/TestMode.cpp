/** -----------------------------------------------------------------------------
 *
 * @file  TestMode.cpp
 * @author Matthew McManness 
 * Assignment:   EECS-268 Lab 3
 * @brief This file describes how Test Mode works.
 * @date 9/27/21
 *
 ---------------------------------------------------------------------------- **/
 #include "TestMode.h"
 #include "StackOfChar.h"
 #include <string>
 using namespace std;
 
TestMode::TestMode()
{
	m_run=0;
}

void TestMode::runTests()
{
	test01();
	test02();
	test03();
	test04();
}

void TestMode::test01()
{
	StackOfChar stack;
	bool check = 0;
	string pass_fail = "";
	check = stack.isEmpty();
	if(check == 0)
	{	
		pass_fail = "FAILED";
	}
	else
	{
		pass_fail = "PASSED";
	}
	cout << "Test #1: New stack is empty:  " << pass_fail << '\n';
}

void TestMode::test02()
{
	StackOfChar stack;
	bool check = 0;
	string pass_fail = "";
	stack.push('x');
	check = stack.isEmpty();
	if(check == 1)
	{	
		pass_fail = "FAILED";
	}
	else
	{
		pass_fail = "PASSED";
	}
	cout << "Test #2: Push on empty stack makes it non-empty: " << pass_fail << '\n';
}

void TestMode::test03()
{
	StackOfChar stack;
	bool check = 0;
	string pass_fail = "";
	stack.push('x');
	stack.pop();
	check = stack.isEmpty();
	if(check == 0)
	{	
		pass_fail = "FAILED";
	}
	else
	{
		pass_fail = "PASSED";
	}
	cout << "Test #3: Popping all all elements makes stack empty: " << pass_fail << '\n';
}

void TestMode::test04()
{
	StackOfChar stack1;
	bool check = 0;
	string pass_fail = "";
	stack1.push('x');
	stack1.push('x');
	stack1.push('y');
	StackOfChar stack2(stack1);
	while(true)
	{
		if((stack1.isEmpty() == 1) && (stack2.isEmpty() == 1))
		{
			check = 1;
			break;
		}
		else if(stack1.peek() == stack2.peek())
		{
			stack1.pop();
			stack2.pop();
		}
		else
		{
			break;
		}
		if((stack1.isEmpty() == 1) && (stack2.isEmpty() == 1))
		{
			check = 1;
			break;
		}
		else if((stack1.isEmpty() == 1) || (stack2.isEmpty() == 1))
		{
			break;
		}
			
	}
	
	if(check == 0)
	{	
		pass_fail = "FAILED";
	}
	else
	{
		pass_fail = "PASSED";
	}
		cout << "Test #4: Copy constructor copies all elements in correct order: " << pass_fail << '\n';
}