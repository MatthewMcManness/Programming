/** -----------------------------------------------------------------------------
 *
 * @file  StackOfChars.h
 * @author Matthew McManness 
 * Assignment:   EECS-268 Lab 3
 * @brief This header file creates an Stack to use with Char Nodes.
 * @date 9/27/21
 *
 ---------------------------------------------------------------------------- **/

#ifndef STACKOFCHAR_H
#define STACKOFCHAR_H

#include "StackInterface.h"
#include "Node.h"

//Our stack will implement the StackInterface but of a stack specifically filled with chars.
//We'll learn in lecture how to make a templated Node and then a templated Stack
class StackOfChar : public StackInterface<char> 
{
	private:
	Node* m_top;
	
	public:
	
	/*
       * @pre None
       * @post creates an empty stack of Char
       * @param None
       * @throw None
    */
	StackOfChar();

	/*
       * @pre None
       * @post Copy Constructor
       * @param orig, the StackOfChar to be copied
       * @throw None
    */
	StackOfChar(const StackOfChar& orig);
	
	/*
       * @pre None
       * @post Destructor
       * @param None
       * @throw None
    */
    ~StackOfChar();

	/*
       * @pre None
       * @post sets the lhs stack of char to be the same as the rhs stack of char
       * @param rhs, another stack of char
       * @throw None
    */
	void operator=(const StackOfChar& rhs);
	
    /*
       * @pre None
       * @post entry is added to top of the stack
       * @param entry, the element to be added to the stack
       * @throw None
    */
	void push(char entry);
	
    /*
       * @pre Stack is non-empty
       * @post Top element is removed from the stack
       * @param None
       * @throw std::runtime_error if pop attempted on empty stack
    */
	void pop();
	
	/*
       * @pre Stack is non-empty
       * @post Top element is returned
       * @param None
       * @throw std::runtime_error if peek attempted on empty stack
    */
	char peek() const; 
	
		/*
       * @pre None
       * @post if stack is empty return true otherwise reuturn false
       * @param None
       * @throw None
    */
	bool isEmpty() const;

};
#endif