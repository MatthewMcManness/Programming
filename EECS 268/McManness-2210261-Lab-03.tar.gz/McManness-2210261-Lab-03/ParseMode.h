/** -----------------------------------------------------------------------------
 *
 * @file  ParseMode.h
 * @author Matthew McManness 
 * Assignment:   EECS-268 Lab 3
 * @brief This header file defines what "Parse Mode" can do.
 * @date 9/27/21
 *
 ---------------------------------------------------------------------------- **/
 
 #ifndef PARSE_MODE_H
#define PARSE_MODE_H

#include <stdexcept>
#include <string>
#include "StackOfChar.h"

using namespace std;

class ParseMode
{
	private: 
	int m_leftBracketCount = 0;
	int m_rightBracketCount = 0;
	string m_sequence = "";
	int m_lengthOfSequence = 0;
	StackOfChar m_stack;
	
	/*
       * @pre None
       * @post This takes a string and stores each character as a node in the stack.
       * @param None
       * @throw None
    */
	void storeSequence();
	
	/*
       * @pre None
       * @post This will print the stored sequence (for testing purposes)
       * @param None
       * @throw None
    */
	void printSequence();
	
	/*
       * @pre None
       * @post This will check to see if the sequence is balanced and call the correct printing method.
       * @param None
       * @throw None
    */
	void checkSequence();
	
	/*
       * @pre None
       * @post This prints "Sequence is Balanced"
       * @param None
       * @throw None
    */
	void printBalanced();
	
	/*
       * @pre None
       * @post This prints "Sequence is not Balanced."
       * @param None
       * @throw None
    */
	void printNotBalanced();
	
	public:
	
	ParseMode();
	
	void run();

};

#endif