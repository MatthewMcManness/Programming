/** -----------------------------------------------------------------------------
 *
 * @file  StackOfChar.cpp
 * @author Matthew McManness 
 * Assignment:   EECS-268 Lab 3
 * @brief This file describes how stacks of characters work.
 * @date 9/27/21
 *
 ---------------------------------------------------------------------------- **/
 
 #include "StackOfChar.h"
 using namespace std;
 
 StackOfChar::StackOfChar()
 {
	 m_top = nullptr;
 }
 
 StackOfChar::StackOfChar(const StackOfChar& orig)
 {
	m_top = orig.m_top;
 }
 
 StackOfChar::~StackOfChar()
 {
	 
 }
 
 void StackOfChar::operator=(const StackOfChar& rhs)
 {
	 m_top = rhs.m_top;
 }
 
 void StackOfChar::push(char entry)
 {
	 Node* newTop = new Node(entry);
	 newTop->setNext(m_top);
	 m_top = newTop;
 }
 
 void StackOfChar::pop()
 {
	 if(this->isEmpty() == true)
	 {
		 throw(runtime_error("Stack is Empty already"));
	 }
	 else
	 {
		 //do I need to set a temporary as top so that I can then delete that node?
		m_top = m_top->getNext();
	 }
 }
	 
char StackOfChar::peek() const
{
	if(this->isEmpty() == true)
	{
		throw(runtime_error("Stack is currently Empty"));
	}
	else
	{
		return(m_top->getEntry());
	}
}
	
bool StackOfChar::isEmpty() const
{
	if(m_top == nullptr)
	{
		return(1);
	}
	else
	{
		return(0);
	}
}