/** -----------------------------------------------------------------------------
 *
 * @file  ParseMode.cpp
 * @author Matthew McManness 
 * Assignment:   EECS-268 Lab 3
 * @brief This file describes how Parse Mode works.
 * @date 9/27/21
 *
 ---------------------------------------------------------------------------- **/
  #include "ParseMode.h"
  #include <iostream>
  #include <string>
  
   using namespace std;
   
 ParseMode::ParseMode()
 {
	 
 }
 
 void ParseMode::storeSequence()
 {
	 m_lengthOfSequence = m_sequence.length();
	 for(int i = 0; i < m_lengthOfSequence; i++)
	 {
		 m_stack.push(m_sequence.at(m_lengthOfSequence - i-1));
	 }
 }
 
 void ParseMode::printSequence()
 {
	 cout << "Your Sequence was: ";
	 for(int i = 0; i < m_lengthOfSequence; i++)
	 {
		 cout << m_stack.peek();
		 m_stack.pop();
	 }
	 cout << '\n';
 }
 
 void ParseMode::run()
 {
	 cout << "Enter your sequence: ";
	 cin >> m_sequence;
	 storeSequence();
	 checkSequence();	 
 }
 
 void ParseMode::checkSequence()
 {
		if(m_stack.isEmpty() == 0)
		{
			if(m_stack.peek() == '}')
			{
				printNotBalanced();
			}
			else if (m_stack.peek() == '{')
			{
				m_leftBracketCount++;

				while(true)
				{
					m_stack.pop();
					if(m_stack.isEmpty() == 1)
					{
						if(m_leftBracketCount == m_rightBracketCount)
						{
							printBalanced();
							break;
						}
						else
						{
							printNotBalanced();
							break;
						}
					}
					else 
					{
						if(m_stack.peek() == '}')
						{	
							m_rightBracketCount++;
						}
						else if(m_stack.peek() == '{')
						{
							m_leftBracketCount++;	
						}
						else
						{
							cout << "\nError\nSequence contains none brackets...\n";
						}
					}
				}
			}
			else 
			{
				cout << "\nError\nSequence contains none brackets...\n";
			}
		}
		else
		{
			printBalanced();
		}
}
 
 
 void ParseMode::printNotBalanced()
 {
	 cout << "Sequence is not balanced.\n";
 }
 
 void ParseMode::printBalanced()
 {
	 cout << "Sequence is balanced.\n";
 }