/** -----------------------------------------------------------------------------
 *
 * @file  main.cpp
 * @author Matthew McManness 
 * Assignment:   EECS-268 Lab 3
 * @brief This is the main file that reads the command line and creates the correct class and calls the correct method depending on what the user wants to do.
 * @date 9/27/21
 *
 ---------------------------------------------------------------------------- **/
 
#include <iostream>
#include <string>
#include "TestMode.h"
#include "ParseMode.h"

using namespace std;

int main(int argc, char* argv[])
{

	if(argc == 2)
	{		
		string command = argv[1];
		
		if(command == "-p")
		{
			ParseMode parse;
			parse.run();
			return(0);
		}
		else if(command == "-t")
		{
			TestMode test;
			test.runTests();
			return(0);
		}
		else
		{
			cout << "Invalid Command Line Input!\n";
			return(0);
		}
	}
	else
	{
		cout << "Incorrect number of parameters!\n";
		return(0);
	}
	
}
