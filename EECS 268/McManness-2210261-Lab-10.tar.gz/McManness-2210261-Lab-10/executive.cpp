/** -----------------------------------------------------------------------------
 *
 * @file  executive.cpp
 * @author Matthew McManness 
 * Assignment:   EECS-268 Lab 9
 * @brief The class file for executive defines how the pokedex will work.
 * @date 12/1/21
 *
 ---------------------------------------------------------------------------- **/

#include <string>
#include <iostream>
#include <fstream>
#include <stdexcept>
#include "pokemon.h"
#include "BST.h"
#include "Node.h"
#include "BSTInterface.h"
#include "executive.h"

using namespace std;

executive::executive(string fileName)
{
	m_fileName = fileName;
}

void executive::openfile()
{
	m_inputFile.open(m_fileName);
}

void executive::run()
{

	openfile();

	if(m_inputFile.is_open())
	{
		m_inputFile >> m_USTemp >> m_IDTemp >> m_JPTemp;
		pokemon temp1(m_IDTemp, m_USTemp, m_JPTemp);
		BinarySearchTree<pokemon, int> pokedex(temp1);
		BinarySearchTree<pokemon, int> pokedexCopy(temp1);
		while(m_inputFile >> m_USTemp >> m_IDTemp >> m_JPTemp)
		{
			pokemon temp(m_IDTemp, m_USTemp, m_JPTemp);
			
			pokedex.add(temp);
		}
		while(true)
		{
			cout << "\nWhat would you like to do?: \n1. Search\n2. Add\n3. Copy\n4. Remove\n5. Print\n6. Quit\nSelection: ";
			cin >> m_command;
		
			if(m_command == 1) //search
			{
				if(m_copied == true)
				{
					while(true)
					{
						cout << "\nWhich Pokedex would you like to search?: \n1. The Original Pokedex\nor\n2. The Copy \nSelection:";
						cin >> m_selection;
					
						if(m_selection == 1)
						{
							cout << "What Pokedex ID would you like to search for?: ";
							cin >> m_key;
							try
							{
								temp1 = pokedex.search(m_key);
								visit(temp1);
								break;
							}
							catch(runtime_error rte)
							{
								cout << "\nPokemon " << rte.what() << '\n';
								break;
							}
						}
						else if(m_selection == 2)
						{
							cout << "What Pokedex ID would you like to search for?: ";
							cin >> m_key;
							try
							{
								temp1 = pokedexCopy.search(m_key);
								visit(temp1);
								break;
							}
							catch(runtime_error rte)
							{
								cout << "\nPokemon " << rte.what() << '\n';
								break;
							}
						}
						else
						{
							cout << "Please enter a number between 1 and 2\n";
						}
					}
				}
				
				else
				{
					cout << "What Pokedex ID would you like to search for?: ";
					cin >> m_key;
					try
					{
						temp1 = pokedex.search(m_key);
						visit(temp1);
					}
					catch(runtime_error rte)
					{
						cout << "\nPokemon " << rte.what() << '\n';
					}
				
				}
			}
			else if(m_command == 2) //add
			{
				if(m_copied == true)
				{
					while(true)
					{
						cout << "\nWhich Pokedex would you like to add to?: \n1. The Original Pokedex\nor\n2. The Copy \nSelection:";
						cin >> m_selection;
					
						if(m_selection == 1)
						{
							cout << "What is the new Pokemon's ID number?: ";
							cin >> m_IDTemp;
				
							cout << "What is the new Pokemon's American name?: ";
							cin >> m_USTemp;
				
							cout << "What is the new Pokemon's Japanese name?: ";
							cin >> m_JPTemp;
				
							pokemon temp(m_IDTemp, m_USTemp, m_JPTemp);
				
							try
							{
								pokedex.add(temp);
								cout << "\nYour Pokemon was added!\n";
								break;
							}
							catch(runtime_error& rte)
							{
								cout << "This Pokemon " << rte.what() << '\n';
								break;
							}
						}
						else if(m_selection == 2)
						{
							cout << "What is the new Pokemon's ID number?: ";
							cin >> m_IDTemp;
				
							cout << "What is the new Pokemon's American name?: ";
							cin >> m_USTemp;
				
							cout << "What is the new Pokemon's Japanese name?: ";
							cin >> m_JPTemp;
				
							pokemon temp(m_IDTemp, m_USTemp, m_JPTemp);
				
							try
							{
								pokedexCopy.add(temp);
								cout << "\nYour Pokemon was added!\n";
								break;
							}
							catch(runtime_error& rte)
							{
								cout << "This Pokemon " << rte.what() << '\n';
								break;
							}
						}
						else
						{
							cout << "Please enter a number between 1 and 2\n";
						}
					}
				}
				else
				{
					cout << "What is the new Pokemon's ID number?: ";
					cin >> m_IDTemp;
				
					cout << "What is the new Pokemon's American name?: ";
					cin >> m_USTemp;
				
					cout << "What is the new Pokemon's Japanese name?: ";
					cin >> m_JPTemp;
				
					pokemon temp(m_IDTemp, m_USTemp, m_JPTemp);
					
					try
					{
						pokedex.add(temp);
						cout << "\nYour Pokemon was added!\n";
					}
					catch(runtime_error& rte)
					{
						cout << "This Pokemon " << rte.what() << '\n';
					}
				}
			}
			else if(m_command == 3) //copy
			{
				m_root = pokedex.getRoot();
				copyHelper(pokedex, pokedexCopy, m_root);
				m_copied = true;
			}
			else if(m_command == 4) //Remove
			{
				if(m_copied == true)
				{
					while(true)
					{
						cout << "\nWhich Pokedex would you like to remove from?: \n1. The Original Pokedex\nor\n2. The Copy \nSelection:";
						cin >> m_selection;
					
						if(m_selection == 1)
						{
							cout << "\nWhat is the Pokedex ID of the pokemon you want to remove from the Pokedex?\nSelection: ";
							cin >> m_key;
							pokedex.remove(m_key);
							break;
						}
						else if(m_selection == 2)
						{
							cout << "\nWhat is the Pokedex ID of the pokemon you want to remove from the Pokedex?\nSelection: ";
							cin >> m_key;
							pokedexCopy.remove(m_key);
							break;
						}
						else
						{
							cout << "Please enter a number between 1 and 2\n";
						}
					}
				}
				else
				{
				cout << "\nWhat is the Pokedex ID of the pokemon you want to remove from the Pokedex?\nSelection: ";
				cin >> m_key;
				pokedex.remove(m_key);
				}
			}
			else if(m_command == 5) // Print
			{
				if(m_copied == false)
				{
					while(true)
					{
						cout << "\nWhat order would you like?: \n1. Pre\n2. In\n3. Post\n";
						cin >> m_order;
				
						if(m_order == 1)
						{
							pokedex.visitPreOrder(visit);
							break;
						}
						else if(m_order == 2)
						{
							pokedex.visitInOrder(visit);
							break;
						}
						else if(m_order == 3)
						{
							pokedex.visitPostOrder(visit);
							break;
						}
						else
						{
							cout << "Please enter a number between 1 and 3\n";
						}
					}
				}
				else
				{
					while(true)
					{
						cout << "\nWhich Pokedex would you like to print from?: \n1. The Original Pokedex\nor\n2. The Copy \nSelection:";
						cin >> m_selection;
					
						if(m_selection == 1)
						{
							while(true)
							{
								cout << "\nWhat order would you like?: \n1. Pre\n2. In\n3. Post\n";
								cin >> m_order;
				
								if(m_order == 1)
								{
									pokedex.visitPreOrder(visit);
									break;
								}
								else if(m_order == 2)
								{
									pokedex.visitInOrder(visit);
									break;
								}
								else if(m_order == 3)
								{
									pokedex.visitPostOrder(visit);
									break;
								}
								else
								{
									cout << "Please enter a number between 1 and 3\n";
								}
							}
							break;
						}
						else if(m_selection == 2)
						{
							while(true)
							{
								cout << "\nWhat order would you like?: \n1. Pre\n2. In\n3. Post\n";
								cin >> m_order;
				
								if(m_order == 1)
								{
									pokedexCopy.visitPreOrder(visit);
									break;
								}
								else if(m_order == 2)
								{
									pokedexCopy.visitInOrder(visit);
									break;
								}
								else if(m_order == 3)
								{
									pokedexCopy.visitPostOrder(visit);
									break;
								}
								else
								{
									cout << "Please enter a number between 1 and 3\n";
								}
							}	
							break;
						}
						else
						{
							cout << "Please enter a number between 1 and 2\n";
						}
					}
				}
					
			}
			else if(m_command == 6) //Quit
			{
				cout << '\n';
				exit(0);
			}
			else
			{
				cout << "Please enter a number between 1 and 6\n";
			}
				
		}
		
	}
	else
	{
		cout << "\nThe file " << m_fileName << " could not be opened.\n\n";
	}	
}

void executive::visit(pokemon poke)
{
	cout << "-------------------\n\nPokedex ID: " << poke.getNum() << "\nAmerican Name: " << poke.getAmerica() << "\nJapanese Name: " << poke.getJapan() << "\n\n--------------------\n";
}

void executive::copyHelper(BinarySearchTree<pokemon, int> pokedex, BinarySearchTree<pokemon, int> pokedexCopy, Node<pokemon>* root)
{

	if(first == true)
	{
		first = false;
		copyHelper(pokedex, pokedexCopy, root->getLeft());
		copyHelper(pokedex, pokedexCopy, root->getRight());
		if(root == nullptr)
		{
			return;
		}
	}
	else
	{
		if(root == nullptr)
		{	
			return;
		}
		pokemon temp;
		temp = root->getEntry();
		pokedexCopy.add(temp);
		copyHelper(pokedex, pokedexCopy, root->getLeft());
		copyHelper(pokedex, pokedexCopy, root->getRight());
	}
	
}




