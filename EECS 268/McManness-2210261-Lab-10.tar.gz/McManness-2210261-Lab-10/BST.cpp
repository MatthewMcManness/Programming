/** -----------------------------------------------------------------------------
 *
 * @file  BST.cpp
 * @author Matthew McManness 
 * Assignment:   EECS-268 Lab 9
 * @brief This is the cpp file that defines the methods of the BinarySearchTree class.
 * @date 12/1/21
 *
 ---------------------------------------------------------------------------- **/
 using namespace std;
 #include <stdexcept>
 #include <iostream>
 #include "Node.h"
 #include "executive.h"
 
 
 template <typename ItemType, typename KeyType>
 BinarySearchTree<ItemType, KeyType>::BinarySearchTree(ItemType first)
 {
	 m_start = new Node<ItemType>(first);
 }
 
 template <typename ItemType, typename KeyType>
 void BinarySearchTree<ItemType, KeyType>::add(ItemType entry)
 {
	 {
		m_temp = m_start;
	
		while(true)
		{
		 
			if(m_temp == nullptr)
			{
				break;
			}
			m_entry = m_temp->getEntry();
			if(m_entry == entry)
			{
				throw(runtime_error("already exists!"));
			}
			else
			{
				if(m_entry > entry)
				{
					m_temp = m_temp->getLeft();
				}
				else
				{
					m_temp = m_temp->getRight();
				}
			}
		}
		
		m_temp = m_start;
		m_new = new Node<ItemType>(entry);
		while(true)
		{
			m_entry = m_temp->getEntry();
			if(m_entry > entry)
			{
				if(m_temp->getLeft() == nullptr)
				{
					m_temp->setLeft(m_new);
					break;
				}
				else
				{
					m_temp = m_temp->getLeft();
				}
			}
			else if (m_entry < entry)
			{
				if(m_temp->getRight() == nullptr)
				{
					m_temp->setRight(m_new);
					break;
				}
				else
				{
					m_temp = m_temp->getRight();
				}
			}
		}
	 }
 }

template <typename ItemType, typename KeyType>
ItemType BinarySearchTree<ItemType, KeyType>::search(KeyType key)
 {
	 m_temp = m_start;
	
	 while(true)
	 {
		 
		if(m_temp == nullptr)
		{
			throw(runtime_error("does not exist"));
		}
		 m_entry = m_temp->getEntry();
		if(m_entry == key)
		{
			return(m_entry);
		}
		else
		{
			if(m_entry > key)
			{
				m_temp = m_temp->getLeft();
			}
			else
			{
				m_temp = m_temp->getRight();
			}
		}
	 }
		
 }

template <typename ItemType, typename KeyType>
void BinarySearchTree<ItemType, KeyType>::clear()
{
	m_start = nullptr;
}
 

template <typename ItemType, typename KeyType>
void BinarySearchTree<ItemType, KeyType>::remove(KeyType key)
 {
	 if(m_first == true)
	 {
	 m_temp = m_start;
	 m_first = false;
	 }
	 Node<ItemType>* tempRight = nullptr;
	  Node<ItemType>* tempLeft = nullptr;
	  ItemType tempRightEntry;
	  ItemType tempLeftEntry;
	  
	  if(m_temp->getLeft() != nullptr)
	  {
	 tempLeft =  m_temp->getLeft();
	 tempLeftEntry = tempLeft->getEntry();
	  }
	  
	 if(m_temp->getRight() != nullptr)
	 {
	 tempRight = m_temp->getRight();	 
	 tempRightEntry = tempRight->getEntry();
	 }
	 
	
	 ItemType tempEntry = m_temp->getEntry();
	 if(tempLeftEntry == key)
	 {
		 if((tempLeft->getRight() == nullptr) && (tempLeft->getLeft() == nullptr))
		{
			m_temp->setLeft(nullptr);
		}
		else if((tempLeft->getLeft() == nullptr) && (tempLeft->getRight() != nullptr))
		{
			m_temp->setLeft(tempLeft->getRight());
		}
		else if((tempLeft->getLeft() != nullptr) && (tempLeft->getRight() == nullptr))
		{
			m_temp->setLeft(tempLeft->getLeft());
		}
		else if((tempLeft->getLeft() != nullptr) && (tempLeft->getRight() != nullptr))
		{
			Node<ItemType>* newTemp = nullptr;
			newTemp = tempLeft->getRight();
			while(newTemp->getLeft() != nullptr)
			{
				newTemp = newTemp->getLeft();
			}
			newTemp->setLeft(tempLeft->getLeft());
			m_temp->setLeft(tempLeft->getRight());
		}
		return;
	 }
	else if(tempRightEntry == key)
	{
		if((tempRight->getRight() == nullptr) && (tempRight->getLeft() == nullptr))
		{
			m_temp->setRight(nullptr);
		}
		else if((tempRight->getRight() == nullptr) && (tempRight->getLeft() != nullptr))
		{
			m_temp->setRight(tempRight->getLeft());
		}
		else if((tempRight->getRight() != nullptr) && (tempRight->getLeft() != nullptr))
		{
			Node<ItemType>* newTemp = nullptr;
			newTemp = tempRight->getRight();
			while(newTemp->getLeft() != nullptr)
			{
				newTemp = newTemp->getLeft();
			}
			newTemp->setLeft(tempRight->getLeft());
			m_temp->setRight(tempRight->getRight());


		}
		else if((tempRight->getRight() != nullptr) && (tempRight->getLeft() == nullptr))
		{
			m_temp->setRight(tempRight->getLeft());
		}
		return;
	} 
	else
	{		
		if(tempEntry > key)
		{
			m_temp = m_temp->getLeft();
			remove(key);
		}
		else
		{
			m_temp = m_temp->getRight();
			remove(key);
		}
	}
	/*
	 Node<ItemType>* temp = nullptr;
	
	 while(true)
	 {
		 
		if(m_temp == nullptr)
		{
			throw(runtime_error("does not exist"));
		}
		 m_entry = m_temp->getEntry();
		if(m_entry == key)
		{
			temp = m_temp;
			temp = temp->getLeft();
			while(!(temp == nullptr))
			{
					temp = temp->getRight();
			}
			if(m_temp->getRight() != nullptr)
			{
			Node<ItemType>* temp2 = m_temp->getRight();
			temp->setRight(temp2);
			}
			m_temp = temp;
			return;
		}
		else
		{
			if(m_entry > key)
			{
				m_temp = m_temp->getLeft();
			}
			else
			{
				m_temp = m_temp->getRight();
			}
		}
	 }
	 */
		
 }

 

    //For the following methods, each method will take a function as a parameter
    //These function then call the provided function on every entry in the tree in the appropriate order (i.e. pre, in, post)
    //The function you pass in will need to a static method
template <typename ItemType, typename KeyType>
void BinarySearchTree<ItemType, KeyType>::visitPreOrder(void visit(ItemType)) const
{
	visitPreOrderTool(visit, m_start);
	
}

template <typename ItemType, typename KeyType>
void BinarySearchTree<ItemType, KeyType>::visitPreOrderTool(void visit(ItemType), Node<ItemType>* root) const
{
	if(root == nullptr)
	{
		return;
	}
	visit(root->getEntry());
	visitPreOrderTool(visit, root->getLeft());
	visitPreOrderTool(visit, root->getRight());
	
}


template <typename ItemType, typename KeyType>
void BinarySearchTree<ItemType, KeyType>::visitInOrder(void visit(ItemType)) const
{
	visitInOrderTool(visit, m_start);
	
}

template <typename ItemType, typename KeyType>
void BinarySearchTree<ItemType, KeyType>::visitInOrderTool(void visit(ItemType), Node<ItemType>* root) const
{
	if(root == nullptr)
	{
		return;
	}
	visitInOrderTool(visit, root->getLeft());
	visit(root->getEntry());
	visitInOrderTool(visit, root->getRight());
	
}

template <typename ItemType, typename KeyType>
void BinarySearchTree<ItemType, KeyType>::visitPostOrder(void visit(ItemType)) const
{
	visitPostOrderTool(visit, m_start);
	
}

template <typename ItemType, typename KeyType>
void BinarySearchTree<ItemType, KeyType>::visitPostOrderTool(void visit(ItemType), Node<ItemType>* root) const
{
	if(root == nullptr)
	{
		return;
	}
	visitPostOrderTool(visit, root->getLeft());
	visitPostOrderTool(visit, root->getRight());
	visit(root->getEntry());
	
}

template <typename ItemType, typename KeyType>
Node<ItemType>* BinarySearchTree<ItemType, KeyType>::getRoot() const
 {
	 return(m_start);
 }
 
 