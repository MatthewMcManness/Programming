/** -----------------------------------------------------------------------------
 *
 * @file  BST.h
 * @author Matthew McManness 
 * Assignment:   EECS-268 Lab 9
 * @brief This is the header file that describes what the BinarySearchTree can do.
 * @date 12/1/21
 *
 ---------------------------------------------------------------------------- **/
#ifndef BST_H
#define BST_H

#include "Node.h"
template <typename ItemType, typename KeyType>
class BinarySearchTree
{
	private:
	Node<ItemType>* m_start = nullptr;
	Node<ItemType>* m_temp = nullptr;
	Node<ItemType>* m_new = nullptr;
	Node<ItemType>* m_left = nullptr;
	Node<ItemType>* m_right = nullptr;
	ItemType m_entry;
	ItemType m_entry_left;
	ItemType m_entry_right;
	bool m_copied = false;
	bool m_first = true;
    public:
	BinarySearchTree(ItemType first);
    virtual ~BinarySearchTree(){}
    virtual void add(ItemType entry); //throws std::runtime_error if duplicate added
    virtual ItemType search(KeyType key); //throws std::runtime_error if not in tree
    virtual void clear(); //Empties the tree
	Node<ItemType>* getRoot() const;
    virtual void remove(KeyType key); //throws std::runtime_error if not in tree

    //For the following methods, each method will take a function as a parameter
    //These function then call the provided function on every entry in the tree in the appropriate order (i.e. pre, in, post)
    //The function you pass in will need to a static method
   virtual void visitPreOrder(void visit(ItemType)) const; //Visits each node in pre order
   void visitPreOrderTool(void visit(ItemType), Node<ItemType>* root) const;
   virtual void visitInOrder(void visit(ItemType)) const; //Visits each node in in order
   void visitInOrderTool(void visit(ItemType), Node<ItemType>* root) const;
   virtual void visitPostOrder(void visit(ItemType)) const; //Visits each node in post order
	void visitPostOrderTool(void visit(ItemType), Node<ItemType>* root) const;
	void copy(ItemType);
	
};

#include "BST.cpp"
#endif