/** -----------------------------------------------------------------------------
 *
 * @file  executive.cpp
 * @author Matthew McManness 
 * Assignment:   EECS-268 Lab 9
 * @brief The header file for executive class.
 * @date 12/1/21
 *
 ---------------------------------------------------------------------------- **/
#ifndef EXECUTIVE_H
#define EXECUTIVE_H

#include <string>
#include <iostream>
#include <fstream>
#include <stdexcept>
#include "pokemon.h"
#include "BST.h"
#include "Node.h"
#include "BSTInterface.h"

using namespace std;



class executive
{
	private:
	string m_fileName= "";
	int m_command = 0;
	ifstream m_inputFile;
	int m_order = 0;
	int m_IDTemp = 0;
	int m_key = 0;
	string m_USTemp = "";
	string m_JPTemp = "";
	bool m_copied = false;
	Node<pokemon>* m_root = nullptr;
	bool first = true;
	int m_selection = 0;
	
	
	
	public:
	executive(string fileName);

	void run(); // interactes with the file 
	void openfile(); // opens the file
	static void visit(pokemon poke);
	void copyHelper(BinarySearchTree<pokemon, int> pokedex, BinarySearchTree<pokemon, int> pokedexCopy, Node<pokemon>* root);
	
};

#endif