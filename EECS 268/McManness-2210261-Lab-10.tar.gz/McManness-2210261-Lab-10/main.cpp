/* -----------------------------------------------------------------------------
 *
 * File Name:  main.cpp
 * Author: Matthew McManness
 * Assignment:   EECS-268 Lab 9
 * Description:  
 * Date: 12-1-2021
 *
 ---------------------------------------------------------------------------- */
#include <iostream>
#include <fstream>
#include <string>
#include "Node.h"
#include "pokemon.h"
#include "BSTInterface.h"
#include "BST.h"
#include "executive.h"


using namespace std;


int main(int argc, char* argv[])
{

	if(argc == 2)
	{		

			executive pokedex(argv[1]);
			
			pokedex.run();

			return(0);
			
	}
	else
	{
		cout << "Incorrect number of parameters!\n";
		return(0);
	}
}
