/* -----------------------------------------------------------------------------
 *
 * File Name:  main.cpp
 * Author: Matthew McManness
 * Assignment:   EECS-168 Lab 4 Exercise 2
 * Description:  Calculate sum, average, min, and max for the array of doubles.
 * Date: 7-1-2021
 *
 ---------------------------------------------------------------------------- */
//Computation
#include <iostream>

int main()
{
	//Declare Variables
	int size = 5;
	double userArray[size];
	double arraySum = 0;
	double arrayAverage = 0;
	double arrayMinimum = 0;
	double arrayMaximum = 0;
	
	
	//collect data from user
	std::cout << "Please enter " << size << " numbers\n" ;

	for (int i = 0; i < size; i++)
	{
		std::cout << "Input number " << i +1 << " into your array: ";
		std::cin >> userArray[i];
	}
	
	//output array data to user
	std::cout << "\nHere are all the numbers in your array:\n";
	for (int i = 0; i < size; i++)
	{
		std::cout << userArray[i] << "\n";
	}
	
	//Sum
	for (int i = 0; i < size; i++)
	{
		arraySum = arraySum + userArray[i];
	}
	std::cout << "The sum of all the values is: " << arraySum << "\n";
	
	//Average
	arrayAverage = arraySum/size;
	std::cout << "The average of all the values is: " << arrayAverage << "\n";
	
	//Max
	for (int i = 0; i < size; i++)
	{
		if (userArray[i] > arrayMaximum)
		{
		arrayMaximum = userArray[i]; 	
		}
	}
	std::cout << "The largest value is : " << arrayMaximum << "\n";
		
	//Min
	arrayMinimum = arrayMaximum;
	for (int i = 0; i < size; i++)
	{
		if (userArray[i] < arrayMinimum)
		{
		arrayMinimum = userArray[i]; 	
		}
	}
	std::cout << "The smallest value is : " << arrayMinimum << "\n";
	return(0);
}