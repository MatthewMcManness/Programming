/* -----------------------------------------------------------------------------
 *
 * File Name:  main.cpp
 * Author: Matthew McManness
 * Assignment:   EECS-168 Lab 4 Exercise 1
 * Description:  Present the user with a menu for picking the size of an nXn chess board and the position of a lone Rook.
				The positions will range from 0 up to, but not including, n. Obtain the row then the column. 
				You will then print the nxn board displaying where the Rook could travel.
 *Date: 7-1-2021
 ---------------------------------------------------------------------------- */
//RookPath
#include <iostream>
 
int main()
{
	//initialize variables 
	int size = 0;
	int rookRow = 0;
	int rookCollumn = 0;

	
	//Collect a size and position
	std::cout << "What size of chessboard would you like? (size = (youranswer)x(youranswer): ";
	std::cin >> size;
	std::cout << "What row do you want the rook to be on? (must be between 0 and "<< size-1 << "): ";
	std::cin >> rookRow;
	while ((rookRow < 0) || (rookRow >= size))
	{
	std::cout << "Error: input must be between 0 and "<< size-1 << "\nWhat row do you want the rook to be on?: ";
	std::cin >> rookRow;
	}
	std::cout << "What collumn do you want the rook to be on? (must be between 0 and "<< size-1 << "): ";
	std::cin >> rookCollumn;
	while ((rookCollumn < 0) || (rookCollumn >= size))
	{
		std::cout << "Error: input must be between 0 and "<< size-1 << "\nWhat collumn do you want the rook to be on?: ";
		std::cin >> rookCollumn;
	}
	
	//display the output
	for (int i = 0; i < size; i++)
	{
		for (int j = 0; j < size; j++)
		{
			if (i == rookRow)
			{
				if (j == rookCollumn)
				{	
				std::cout << "R";
				}
				else
				{
				std::cout << "-";
				}
			}
			else 
			{	
				if (j == rookCollumn)
				{
					std::cout << "|";
				}
				else
				{
					std::cout << "*";
				}
				
			}
		}
		std::cout << "\n";
	}
	

	
	
	return(0);
}