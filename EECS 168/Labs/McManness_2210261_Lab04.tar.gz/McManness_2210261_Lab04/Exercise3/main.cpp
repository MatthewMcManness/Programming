/* -----------------------------------------------------------------------------
 *
 * File Name:  main.cpp
 * Author: Matthew McManness
 * Assignment:   EECS-168 Lab 4 Exercise 3
 * Description:  
	search for a value from an array created in the program.
 * Date: 7-1-2021
 *
 ---------------------------------------------------------------------------- */
 //arraysWithFileInput
#include <fstream>

#include <iostream>


int main()
{
	int searchValue = 0;
	char quitValue = '\0';
	std::ifstream inputFile;
	int* array = nullptr;
	int size = 0;
	inputFile.open("input.txt");
	inputFile >> size;
	array = new int[size];
	for(int i=0; i<size; i++)
	{
		inputFile >> array[i];
	}
	inputFile.close();
	std::cout << "Contents of input.txt:\n[";
	for(int i=0; i<size; i++)
	{
		std::cout << array[i];
		if (i<size-1)
		{
			std::cout << ", ";
		}
	}
	std::cout << "]\n\n";
	
	do
	{
		std::cout << "Input a value to search for: ";
		std::cin >> searchValue;
		for (int i = 0; i<size; i++)
		{
			if(searchValue == array[i])
			{
				std::cout << searchValue << " is in the array.\n";
				break;
			}
			else
			{
				if( i == size -1)
				{
						std::cout << searchValue << " is not in the array.\n";
				}
			}
		}
		std::cout << "Do you wish to quit? (y/n):";
		std::cin >> quitValue;
		while((quitValue != 'y') && (quitValue != 'Y') && (quitValue != 'n') && (quitValue != 'N'))
		{
			std::cout << "Invalid Input.\nDo you wish to quit? (y/n):";
			std::cin >> quitValue;
		}
		
	}while ((quitValue != 'y') && ( quitValue != 'Y'));
	
	delete[] array;
	return(0);
}