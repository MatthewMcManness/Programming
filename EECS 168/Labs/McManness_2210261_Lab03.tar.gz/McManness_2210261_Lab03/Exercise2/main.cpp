/* -----------------------------------------------------------------------------
 *
 * File Name:  main.cpp
 * Author: Matthew McManness
 * Assignment:   EECS-168 Lab 3 Exercise 2
 * Description:  play a number guessing game.
 * Date: 6-28-2021
 *
 ---------------------------------------------------------------------------- */
#include <iostream>
#include <stdlib.h>
#include <time.h>

int main()
{
	//
	srand( time(NULL) );
	int secretNum = 0;
	int guess = 0;
	int closeGuess = 0;
	int guessCount = 0;
	char userChoice = 'y';
	
	
	//
	std::cout << "Welcome to the number guessing game.\n" ;

	//
	do
	{
		if(guessCount == 0)
		{
			secretNum = rand() % 100 + 1;
		}
		closeGuess = guess;
		std::cout << "Guess a number: ";
		std::cin >> guess;
		
		if (guess < secretNum)
		{
			std::cout << "Sorry, your guess is too low.\n";
			guessCount++;
		}
		if (guess > secretNum)
		{	
			std::cout << "Sorry, your guess is too high.\n";
			guessCount++;
		}
		if (guess == secretNum)
		{
			std::cout << "You win!\nYou guessed the secret number after " << guessCount << " guess(es).\n";
			std::cout << "Your closest guess was " << closeGuess << ".\n";
			guessCount = 0;
			std::cout << "Would you like to play again? (y/n): ";
			std::cin >> userChoice;
			while ( (userChoice != 'y') && (userChoice != 'Y') && (userChoice != 'n') && (userChoice != 'N'))
			{
				std::cout << "you must enter a 'y' or a 'n'.\n";
				std::cout << "Would you like to play again? (y/n): ";
				std::cin >> userChoice;
			}
	
		}
	}
	while ((userChoice == 'y') || (userChoice == 'Y')); 

	return(0);
}