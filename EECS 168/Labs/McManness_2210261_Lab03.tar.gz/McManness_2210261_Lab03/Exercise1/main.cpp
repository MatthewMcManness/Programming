/* -----------------------------------------------------------------------------
 *
 * File Name:  main.cpp
 * Author: Matthew McManness
 * Assignment:   EECS-168 Lab 2 Exercise 1
 * Description:  Create a program, CharacterCount that will obtain a string (assume no whitespace) from the user. 
				Then ask the user for a single character. Finally print the count of occurences of that that character in the string.
 *Date: 6-28-2021
 ---------------------------------------------------------------------------- */
//CharacterCount
#include <iostream>
#include <string>
 
int main()
{
	//initialize variables 
	std::string input = "";
	char userChar = '\0';
	int stringLength = 0;
	int position = 0;
	int count = 0;
	
	//Collect a string and and chosen character
	std::cout << "Enter a string: ";
	std::cin >> input;
	std::cout << "Enter a character to count: ";
	std::cin >> userChar;
	
	//Calculate how many times the character happens
	stringLength = input.length();
	
	while (position < stringLength)
	{
		if (input.at(position) == userChar)
		{
			count = count + 1;
		}
		position = position + 1;
	}
	//Output to user
	std::cout << "In the string " << input << " the character '" << userChar << "' occurs " << count << " time(s).\n";
	
	
	return(0);
}