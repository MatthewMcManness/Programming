/* -----------------------------------------------------------------------------
 *
 * File Name:  main.cpp
 * Author: Matthew McManness
 * Assignment:   EECS-168 Lab 3 Exercise 4
 * Description:  You will make a program that will ask the user for what day they want a count of people with the flu for. Then display the amount.
 * Date: 6-28-2021
 *
 ---------------------------------------------------------------------------- */
//Outbreak!
#include <iostream>

int main()
{
	int infected[48];
	infected[0] = 1;
	infected[1] = 8;
	infected[2] = 22;
	int choice = 0;
	for(int i = 3; i <=48; i++)
	{
		infected[i] = infected[i-1] + infected[i-2] + infected[i-3];
	}
	std::cout << "OUTBREAK!\nWhat day do you want a sick count for?: ";
	std::cin >> choice;
	if ((choice < 1) || (choice > 48))
	{
		std::cout << "Invalid day\n";
	}
	else
	{	
	std::cout << "Total people with the flu: " << infected[choice - 1] << "\n";
	}
	return(0);
}