/* -----------------------------------------------------------------------------
 *
 * File Name:  main.cpp
 * Author: Matthew McManness
 * Assignment:   EECS-168 Lab 3 Exercise 3
 * Description:  ASCII Program
 * Date: 6-28-2021
 *
 ---------------------------------------------------------------------------- */
#include <iostream>


int main()
{
	int menuChoice = 0;
	int intChoice = 0;
	do
	{
		std::cout << "1) Select a specific ASCII character provided an int\n2) Display visible ASCII values (33 to 126)\n3) Exit \n";
		std::cin >> menuChoice;
		while((menuChoice < 1) || (menuChoice > 3))
		{
			std::cout << "1) Select a specific ASCII character provided an int\n2) Display visible ASCII values (33 to 126)\n3) Exit \n";
			std::cin >> menuChoice;
		}	
		if(menuChoice == 1)
		{
			std::cout << "Choice: " << menuChoice << "\n";
			std::cout << "Enter value: ";
			std::cin >> intChoice;
			std::cout << intChoice << " = " << static_cast<char>(intChoice) << "\n\n";
			if((intChoice > 127) || (intChoice < 32))
			{
				std::cout << "**Error!**\nValue must be between 33 and 126.\n\n";
			}

		}
		if(menuChoice == 2)
		{
			std::cout << "Choice: " << menuChoice << "\n";
			for(int i=33;i <= 126; i++)
			{
				std::cout << i << " = " << static_cast<char>(i) << "\n";
			}
			std::cout << "\n";
		}
		if(menuChoice == 3)
		{
			std::cout << "Choice: " << menuChoice << "\nGoodbye!\n\n";
			break;
		}
	}
	while(1);
	
	
	return(0);
}