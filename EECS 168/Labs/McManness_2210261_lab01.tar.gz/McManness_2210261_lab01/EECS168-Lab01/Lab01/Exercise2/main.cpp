#include <iostream>

int main()
{
std::cout << "My name is Matthew McManness.\n";
std::cout << "I am a computer science major.\n";
std::cout << "My hobbies are:\n";
std::cout << "\tReading\n";
std::cout << "\tModding\n";
std::cout << "\tRaising foster kittens\n";
std::cout << "\tHiking\n";
std::cout << "Goodbye\n";
return(0);
}



