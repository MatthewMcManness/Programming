#include<iostream>

int main()
{
std::cout<<"\tThis is my first lab exercise!\n";
return(0);
}
