#include <iostream>

int main()
{
	//initialize a Variable for wind speed in m/s
	int windSpeed = 0;
	
	//Ask the user to input the windspeed and store their input into windSpeed variable
	std::cout << "Input a wind speed (m/s): ";
	std::cin >> windSpeed;
	
	//Output based on the input
	if (windSpeed<0)
	{
		std::cout << "Wind speed cannot be negative, Sorry, that is invalid.\n";
	}
	else 
	{
		if (windSpeed<18)
		{
			std::cout << "A wind speed of " << windSpeed << "m/s is a tropical depression.";
		}
	
		else
		{
			if (windSpeed<33)
			{
				std::cout << "A wind speed of " << windSpeed << "m/s is a tropical storm.\n";
			}
	
			else
			{
				if (windSpeed<43)
				{
				std::cout << "A wind speed of " << windSpeed << "m/s is a Category 1 hurricane.\n";
				}
	
				else
				{
					if (windSpeed<50)
					{
						std::cout << "A wind speed of " << windSpeed << "m/s is a Category 2 hurricane.\n";
					}
	
					else
					{
						if (windSpeed<58)
						{
						std::cout << "A wind speed of " << windSpeed << "m/s is a Category 3 hurricane.\n";
						}
	
						else
						{
							if (windSpeed<70)
							{
								std::cout << "A wind speed of " << windSpeed << "m/s is a Category 4 hurricane.\n";
							}
	
							else
							{
								std::cout << "A wind speed of " << windSpeed << "m/s is a Category 5 hurricane.\n";
							}
						}
					}
				}
			}
		}
	}
	return(0);
}