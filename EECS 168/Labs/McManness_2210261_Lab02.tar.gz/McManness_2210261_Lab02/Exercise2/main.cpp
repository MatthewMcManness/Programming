#include <iostream>

int main()
{
	//Declare Variables for the Numberator and Denomenator
	int numerator = 0;
	int denomenator = 0;
	
	//User input for values
	std::cout << "Enter a numerator: ";
	std::cin >> numerator;
	
	std::cout << "Enter a denomenator: ";
	std::cin >> denomenator;
	
	//Output to user
	if (denomenator==0)
	{
		std::cout << "Sorry, it is not possible to divide by zero.\n";
	}
	else 
	{
		std::cout << numerator << " / " << denomenator << " = " << numerator/denomenator << " Remainder " << numerator%denomenator << "\n"; 
	}
	return(0);
}