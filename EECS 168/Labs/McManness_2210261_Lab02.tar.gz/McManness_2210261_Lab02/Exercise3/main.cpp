#include <iostream>

int main()
{
	//To make outputs into the format for money
	std::cout.precision(2);
	std::cout << std::fixed;
	
	//Declare Variables
	char choice = 'n';
	//Amounts
	int numberOfSalads = 0;
	int	numberOfDrinks = 0;
	int numberOfCakes = 0;
	//Age
	int customerAge = 0;
	//Prices
	double priceOfSalads = 4.25;
	double priceOfDrinks = 1.05;
	double priceOfCakes = 3.55;
	//Total prices for customer by item
	double totalForSalads = 0;
	double totalForDrinks = 0;
	double totalForCakes = 0;
	//final calculation rates
	double subtotal = 0;
	double discountRate = 0.0;
	double discountAmount = 0;
	double taxRate = 0.05;
	double taxAmount = 0;
	double totalCharge = 0;
	
	//User Interface and user inputs for Salad
	std::cout << "==============================\nWelcome to the Restaurant!\n==============================\n\nDo you want Salads? (y/n): "; 
	std::cin >> choice;
	
	if((choice == 'y') || (choice == 'Y'))
	{
		std::cout << "How many would you like?: ";
				std::cin >> numberOfSalads;

			
				if (numberOfSalads<0)
				{
				numberOfSalads=0;
				}
		
	}
		else 
		{
			if ((choice != 'n') && (choice != 'N'))
			{
				std::cout << "I am sorry I do not understand your answer.\n";
			}
		}
	
	//User Inputs for Drinks
		std::cout << "\nDo you want Drinks? (y/n): "; 
	std::cin >> choice;	
		
	if((choice == 'y') || (choice == 'Y'))
	{
		std::cout << "How many would you like?: ";
				std::cin >> numberOfDrinks;
			
				if (numberOfDrinks<0)
				{
				numberOfDrinks=0;
				}
		
	}
		else 
		{
			if ((choice != 'n') && (choice != 'N'))
			{
				std::cout << "I am sorry I do not understand your answer.\n";
			}
		}
	
	//User Inputs for Cakes
	std::cout << "\nDo you want Cakes? (y/n): "; 
	std::cin >> choice;	
		
	if((choice == 'y') || (choice == 'Y'))
	{
		std::cout << "How many would you like?: ";
				std::cin >> numberOfCakes;
			
				if (numberOfCakes<0)
				{
				numberOfCakes=0;
				}
		
	}
		else 
		{
			if ((choice != 'n') && (choice != 'N'))
			{
				std::cout << "I am sorry I do not understand your answer.\n";
			}
		}
		
	//Determine Customer Age
	std::cout << "\n\nHow old are you?: ";
	std::cin >> customerAge;
	
	//Baseline Calculations
	totalForSalads = (numberOfSalads * priceOfSalads);
	totalForDrinks = (numberOfDrinks * priceOfDrinks);
	
	if(5 >= customerAge)
	{
		priceOfCakes = 0;
	}
	
	totalForCakes = numberOfCakes * priceOfCakes;
	subtotal = (totalForSalads + totalForDrinks + totalForCakes);		
	taxAmount = (subtotal * taxRate);
	
	if(65 <= customerAge)
	{
		discountRate = 0.1;
	}
	
	discountAmount = (subtotal * discountRate);
	
	//Baseline Output
	std::cout << "==============================\n" << numberOfSalads << " Salads @ $" << priceOfSalads << " ==> $" << totalForSalads << "\n";
	std::cout << numberOfDrinks << " Drinks @ $" << priceOfDrinks << " ==> $" << totalForDrinks << "\n";
	std::cout << numberOfCakes << " Cakes @ $" << priceOfCakes << " ==> $" << totalForCakes << "\n";
	std::cout << "Subtotal: $" << subtotal << "\n";
	std::cout << "Tax: $" << taxAmount << "\n";
	
	if(65 <= customerAge)
	{
		std::cout << "Discount: $" << discountAmount << "\n";
	}
	
	totalCharge = (subtotal + taxAmount + discountAmount);
	std::cout << "==============================\nTotal: $" << totalCharge << "\n\nPlease come again!\n";
	
	
	return(0);
}