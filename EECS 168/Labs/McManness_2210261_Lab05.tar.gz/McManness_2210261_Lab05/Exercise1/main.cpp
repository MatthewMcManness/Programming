/* -----------------------------------------------------------------------------
 *
 * File Name:  main.cpp
 * Author: Matthew McManness
 * Assignment:   EECS-168 Lab 5 
 * Description:  Present the user with a menu with a variety of function choices.
 *Date: 7-8-2021
 ---------------------------------------------------------------------------- */
//prog
#include <iostream>
using namespace std;

 int lastDigit(int n);
 int removeLastDigit(int n);
 int addDigit(int currentNum, int newDigit);
 int reverse(int n);
 bool isPalindrome(int n);
 int countDigits(int n);
 int sumDigits(int n);
 int getPositiveInteger();
 void printMenu();
 void run();
 
int main()
{ 
  run();
  return(0);
}


void run()
 {
	 int userChoice = 0;
	 int userNumber = 0;
	 int digitCount = 0;
	 int sumOfDigits = 0;
	 int numReverse = 0;
	 bool isNumberPalindrome = 0;
	 while ((userChoice < 1) || (userChoice > 5))
	 {
		printMenu();
		cin >> userChoice;
		
		if((userChoice < 1) || (userChoice > 5))
		{
			cout << "\n**Error**\nPlease enter a valid number\n\n";
		}
		
		if(userChoice == 1)
		{
			userNumber = getPositiveInteger();
			digitCount = countDigits(userNumber);
			cout << "\nYour integer has " << digitCount << " digits.\n\n";
			userChoice = 0;
		}
		
		if(userChoice == 2)
		{
			userNumber = getPositiveInteger();
			sumOfDigits = sumDigits(userNumber);
			cout << "\nThe sum of the digits in your integer is " << sumOfDigits << ".\n\n";
			userChoice = 0;
		}
		
		if(userChoice == 3)
		{
			userNumber = getPositiveInteger();
			isNumberPalindrome = isPalindrome(userNumber);
			if(isNumberPalindrome == 1)
			{
			cout << "\nYour integer is a Palindrome!\n\n";
			}
			else
			{
			cout << "\nYour integer is not a Palindrome!\n\n";
			}
			userChoice = 0;
		}
		
		if(userChoice == 4)
		{
			userNumber = getPositiveInteger();
			numReverse = reverse(userNumber);
			cout << "\nYour integer in reverse is " << numReverse << ".\n\n";
			userChoice = 0;
		}
		
		if(userChoice == 5)
		{
			
			cout << "\nGoodbye!\n\n";
			return;
		}
	 }
 }
 
 
 void printMenu()
 {
	 cout << "1) Count digits\n2) Sum digits\n3) Is Palindrome\n4) Reverse\n5) Exit\nChoice:";
 }
 
 
 int lastDigit(int n)
 {
	 n = n % 10;
	 return(n);
 }
 
 
 int removeLastDigit(int n)
 {
	 n = n / 10;
	 return(n);
 }
 
 int sumDigits(int n)
 {
	int digitToAdd = 0;
	int sumOfDigits = 0;
	while (n > 0)
	{
		digitToAdd = lastDigit(n);
		n = removeLastDigit(n);
		sumOfDigits = sumOfDigits + digitToAdd;
	}
	return(sumOfDigits);
 }
 
 
 int countDigits(int n)
 {
	 int digitCount = 0;
	 while(n>0)
	{
		n = removeLastDigit(n);
		digitCount++;
	}
	 return(digitCount);
 }
 
 
  int getPositiveInteger()
  {
	 int userNumber = -1;
	 while (userNumber < 0)
		{
			cout << "\nPlease enter a positive integer: ";
			cin >> userNumber;
			if (userNumber < 0)
			{
				cout << "\n**Error**\n\n";
			}
		}
	return(userNumber);	
  }
  
  
  bool isPalindrome(int n)
  {
	  if(n == reverse(n))
	  {
		  return(1);
	  }
	  return(0);
  }
  
  int addDigit(int currentNum, int newDigit)
  {
	return((currentNum*10) + newDigit);
  }
  
  int reverse(int n)
  {
	  int digitInUse = 0;
	  int numReverse = 0;
	  while(n>0)
	  {
	  digitInUse = lastDigit(n);
	  numReverse = addDigit(numReverse, digitInUse);
	  n = removeLastDigit(n);
	  }
	  return(numReverse);

  }