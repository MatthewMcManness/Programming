/* -----------------------------------------------------------------------------
 *
 * File Name:  main.cpp
 * Author: Matthew McManness
 * Assignment:   EECS-168 Lab 6 
 * Description:  An array manipulation program that allows the user to 
 *               do pretty much whatever they want to an array.
 * Date: 7-16-2021
 ---------------------------------------------------------------------------- */
//prog
#include <iostream>
#include <string>
#include <fstream>
using namespace std;

int* insert(int arr[ ], int& size, int value, int position);
int* remove(int arr[ ], int& size, int position);
int count(int arr[ ], int size, int target);
void print(int arr[ ], int size);

 
int main(int argc, char** argv)
{ 
	string fileName;
	string arrSizeString;
	int size = 0;
	ifstream inputFile;
	int* arr = nullptr;
	int userChoice = 0;
	int target = 0;
	int arrCount = 0;
	int value = 0;
	int position = 0;

	if(argc == 3)
	{
		fileName = argv[1];
		arrSizeString = argv[2];
		size = stoi(arrSizeString);
	}
	else
	{
		cout << "\nYou must use the correct format for Command line arguments\nPlease try again!\n\n";
		return(0);
	}
	inputFile.open(fileName);
	if(inputFile.is_open())
	{
		arr = new int[size];
		
		for(int i =0; i <size; i++)
		{
			inputFile >> arr[i];
		}
		inputFile.close();

		while(userChoice !=5)
		{
			cout << "\nMake a selection:\n1) Insert\n2) Remove\n3) Count\n4) Print\n5) Exit\nChoice: ";
			cin >> userChoice;

			if(userChoice == 1)
			{
				cout << "\nPlease choose an integer to add to the array: ";
				cin >> value;
				cout << "\nIn what position do you want to add " << value << " to? (must be between 0 and " << size << "): ";
				cin >> position;
				arr = insert(arr, size, value, position);

			}

			if(userChoice == 2)
			{
				cout << "\nWhich integer would you like to remove? (must be between 0 and " << size-1 << "): ";
				cin >> position;
				arr = remove(arr, size, position);
			}

			if(userChoice == 3)
			{
				cout << "\nPlease choose a target integer: ";
				cin >> target;
				arrCount = count(arr, size, target);
				cout << target << " appears in the array " << arrCount << " times.\n\n";
			}
			if(userChoice == 4)
			{
				print(arr, size);
			}
		}
		delete[] arr;
		return(0);
	}
  else
  {
  	cout << "\nThe file " << fileName << " could not be opened.\n\n";
  	return(0);
  }
  return(0);
}

void print(int arr[ ], int size)
{
	cout << "\n\n[";
	for(int i = 0; i<size; i++)
	{
		if(i <size-1)
		{
			cout << arr[i] << ", ";
		}
		else
		{
			cout << arr[i];
		}
	
	}
		cout << "]\n\n";

}

int count(int arr[ ], int size, int target)
{
	int count = 0;
	for(int i = 0; i<size; i++)
	{
		if(arr[i] == target)
		{
			count++;
		}
	}
	return(count);

}

int* insert(int arr[ ], int& size, int value, int position)
{
	int* newArr = nullptr;
	size++;
	newArr = new int[size];
	newArr[position] = value;
	for(int i = 0; i < position; i++)
	{
		newArr[i] = arr[i];
	}

	for(int i = position+1; i < size; i++)
	{
		newArr[i] = arr[i];
	}
	delete[] arr;
	return(newArr);

}

int* remove(int arr[ ], int& size, int position)
{
	int* newArr = nullptr;
	size--;
	newArr = new int[size];
	for(int i = 0; i < position; i++)
	{
		newArr[i] = arr[i];
	}

	for(int i = position; i < size; i++)
	{
		newArr[i] = arr[i+1];
	}
	delete[] arr;
	return(newArr);

}