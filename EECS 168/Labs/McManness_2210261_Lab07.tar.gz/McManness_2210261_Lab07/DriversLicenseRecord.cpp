#include "DriversLicenseRecord.h"
#include <string>
using namespace std;

DriversLicenseRecord::DriversLicenseRecord(string firstName, string lastName, int age, char voterStatus, int licenseNumber)
{
	setFirstName(firstName);
	setLastName(lastName);
	setAge(age);
	setVoterStatus(voterStatus);
	setLicenseNumber(licenseNumber);
}

void DriversLicenseRecord::setFirstName(string firstName)
{
	firstName_m = firstName;
}

void DriversLicenseRecord::setLastName(string lastName)
{
	lastName_m = lastName;
}

void DriversLicenseRecord::setAge(int age)
{
		age_m = age;
}

void DriversLicenseRecord::setVoterStatus(char voterStatus)
{
	voterStatus_m = voterStatus;
}

void DriversLicenseRecord::setLicenseNumber(int licenseNumber)
{
		licenseNumber = licenseNumber_m;
}

string DriversLicenseRecord::getFirstName() const
{
	return(firstName_m);
}

string DriversLicenseRecord::getLastName() const
{
	return(lastName_m);
}

int DriversLicenseRecord::getAge() const
{
	return(age_m);
}

char DriversLicenseRecord::getVoterStatus() const
{
	return(voterStatus_m);
}

int DriversLicenseRecord::getLicenseNumber() const
{
	return(licenseNumber_m);
}

