#include "DMV.h"
#include "DriversLicenseRecord.h"
#include <iostream>
#include <fstream>
#include <string>
#include <stdio.h>
#include <ctype.h>
#include <limits>
using namespace std;

DMV::DMV(string fileName)
{
	ifstream inputFile;
	inputFile.open(fileName);
	if(inputFile.is_open())
	{
		inputFile >> size_m;
		records = new DriversLicenseRecord*[size_m];

		string firstName = "";
		string lastName = "";
		int age = 0;
		char voterStatus = 'N';
		int licenseNumber = 0;
		
		for(int i = 0; i < size_m; i++)
		{
			inputFile >> firstName;
			inputFile >> lastName;
			inputFile >> age;
			inputFile >> voterStatus;
			inputFile >> licenseNumber;
			records[i] = new DriversLicenseRecord(firstName, lastName, age, voterStatus, licenseNumber); 
		}
		this->run();
		exit(0);
	}
	else
  	{
  		cout << "\nThe file " << fileName << " could not be opened.\n\n";
  		exit(0);
  	}
}

DMV::~DMV()
{
	for(int i = 0; i < size_m; i++)
	{
		delete records[i];
	}
	delete[] records;
}

void DMV::run()
{
	int choice = 1;
	while(true)
	{
		while((choice <= 5) && (choice > 0))
		{
			cout << "Select an option: \n1) Print all Drivers Info\n2) Print all voters\n3) Print drivers by last initial\n4) Print drivers in age range\n5) Quit\nEnter your choice: ";
			cin >> choice;
			 while (cin.fail() )
    			{
        			cin.clear(); // unset failbit
        			cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        			cout << "Sorry, your input did not seem to be an int. Try again: ";   
        			cin >> choice;
    			}
				cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
				cout << "You entered: " << choice << "\n\n";


			if(choice == 5)
			{
				cout << "\nProgram exiting\nGoodbye!\n\n";
				break;
			}

			if(choice == 1)
			{
				for(int i = 0; i < size_m; i++)
				{
					cout << records[i]->getLastName() << ", " << records[i]->getFirstName() << " (" << records[i]->getAge() << "): " << records[i]->getLicenseNumber() <<  "\n";
				}
				cout << "\n\n";
			}

			if(choice == 2)
			{
				for(int i = 0; i < size_m; i++)
				{
					if(records[i]->getVoterStatus() == 'Y')
					{
						cout << records[i]->getLastName() << ", " << records[i]->getFirstName() << " (" << records[i]->getAge() << "): " << records[i]->getLicenseNumber() << "\n";
					}
				}
				cout << "\n\n";				
			}

			if(choice == 3)
			{
				char lastInitial = '\0';
				cout << "Enter the first letter of the last names you want printed: ";
				cin >> lastInitial;
				lastInitial = (tolower(lastInitial));
				int counter = 0;
				cout << "\n";
				for(int i = 0; i < size_m; i++)
				{
					string lastName;
					lastName = records[i]->getLastName();
					char Initial = lastName.at(0);
					Initial = (tolower(Initial));
				

					if(Initial == lastInitial)
					{
						counter++;
						cout << records[i]->getLastName() << ", " << records[i]->getFirstName() << " (" << records[i]->getAge() << "): " << records[i]->getLicenseNumber() << "\n";
					}

				}
				cout << "\n";				
				if(counter == 0)
				{
					cout << "No Records Found.\n\n";
				}
			}

			if(choice == 4)
			{
				int lowerbound = -1;
				int upperbound = -1;

				while(lowerbound < 0)
				{
					cout << "Please enter the age of the youngest drivers you would like reported (lowerbound): ";
					cin >> lowerbound;
					while (cin.fail() )
    				{
        				cin.clear(); // unset failbit
        				cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        				cout << "Sorry, your input did not seem to be an int. Try again: ";   
        				cin >> lowerbound;
    				}
					cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
					cout << "You entered: " << lowerbound << "\n\n";
					if(lowerbound < 0)
					{
						cout << "Error: Please enter a positive number.\n\n";
					}
				}

				while(upperbound < lowerbound)
				{
					cout << "Please enter the age of the oldest drivers you would like reported (upperbound): ";
					cin >> upperbound;
					 while (cin.fail() )
    				{
        				cin.clear(); // unset failbit
        				cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        				cout << "Sorry, your input did not seem to be an int. Try again: ";   
        				cin >> upperbound;
    				}
					cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
					cout << "You entered: " << upperbound << "\n\n";
					if(upperbound < lowerbound)
					{
						cout << "Error: Please enter a number bigger than your chosen lowerbound ( " << lowerbound << " )\n\n";
					}
				}
				
				for(int i = 0; i < size_m; i++)
				{
					if((records[i]->getAge() >= lowerbound) && (records[i]->getAge() <= upperbound))
					{
						cout << records[i]->getLastName() << ", " << records[i]->getFirstName() << " (" << records[i]->getAge() << "): " << records[i]->getLicenseNumber() << "\n";
					}
				}
				cout << "\n\n";				
		}
		if((choice <= 0) || (choice > 5))
		{
			cout << "\nPlease enter a choice between 1 and 5.\n\n";
			choice = 1;
		}
		}
		break;
	}
}