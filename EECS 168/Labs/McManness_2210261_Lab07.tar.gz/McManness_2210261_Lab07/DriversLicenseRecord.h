#include <string>
using namespace std;

#ifndef DRIVERS_LICENSE_RECORD_H
#define DRIVERS_LICENSE_RECORD_H

class DriversLicenseRecord
{
	private:
	string firstName_m;
	string lastName_m;
	int age_m;
	char voterStatus_m;
	int licenseNumber_m;

	public:

	DriversLicenseRecord();
	DriversLicenseRecord(string firstName, string lastName, int age, char voterStatus, int licenseNumber);
	
	void setFirstName(string firstName);
	void setLastName(string lastName);
	void setAge(int age);
	void setVoterStatus(char voterStatus);
	void setLicenseNumber(int licenseNumber);
	string getFirstName() const;
	string getLastName() const;
	int getAge() const;
	char getVoterStatus() const;
	int getLicenseNumber() const;

	
} ;

#endif