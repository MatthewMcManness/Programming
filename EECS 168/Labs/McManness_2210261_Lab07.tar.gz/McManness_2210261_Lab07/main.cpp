/* -----------------------------------------------------------------------------
 *
 * File Name:  main.cpp
 * Author: Matthew McManness
 * Assignment:   EECS-168 Lab 7
 * Description:  A program that can read drivers license records a print them to terminal in a variety of ways.
 * Date: 7-22-2021
 ---------------------------------------------------------------------------- */
//prog
#include <iostream>
#include <string>
#include <fstream>
#include "DriversLicenseRecord.h"
#include "DMV.h"
using namespace std;


 
int main(int argc, char** argv)
{ 
	string fileName = "";

    if(argc == 2)
    {
        fileName = argv[1];
    }
    else
    {
        cout << "\nYou must use the correct format for Command line arguments\nPlease try again!\n\n";
        return(0);
    }
    DMV myDMV(fileName);
	return(0);
}