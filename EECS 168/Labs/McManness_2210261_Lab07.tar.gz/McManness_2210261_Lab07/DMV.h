#include <string>
#include <fstream>
#include <iostream>
#include "DriversLicenseRecord.h"
using namespace std;

#ifndef DMV_H
#define DMV_H

class DMV
{
	private:

	int size_m;
	DriversLicenseRecord** records;

	public:
	DMV();
	DMV(string fileName);
	void run();
	~DMV();
} ;

#endif